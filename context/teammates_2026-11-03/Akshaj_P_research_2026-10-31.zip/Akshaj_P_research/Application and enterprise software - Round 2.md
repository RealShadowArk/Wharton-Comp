# Application and enterprise software — Round 2 work pages

Use one page per company after you select the three names. Cite the source and date for each factual answer. Label your judgments and assumptions.

## Company 1

**Ticker, listing and WInS eligibility**  
Your notes

**Business, ten-year plan and competitors**  
Which reported driver matters most, and what would a competitor do to challenge it?

**DCF and reverse DCF**  
Record the October 30 quote, values at beta 1.0, measured beta and adjusted beta, and the implied growth path. Identify your forecast sources and assumptions.

**Bear case**  
What changes in growth and margins? Record base upside, bear downside and their ratio.

**Quality and risk**  
Record Piotroski, Beneish, 60-month risk measures, worst full calendar year and the mechanical ceiling. Identify each MISSING component.

**Dip test**  
What dated fact supports your explanation? What evidence would distinguish a temporary problem from a deteriorating business?

**Price versus evidence**  
What does the current price imply? Write your own conclusion.

**Laura fit and portfolio overlap**  
Review the cash-flow floor, industry exposure and potential overlap. Write your own conclusion.

## Company 2

**Ticker, listing and WInS eligibility**  
Your notes

**Business, ten-year plan and competitors**  
Which reported driver matters most, and what would a competitor do to challenge it?

**DCF and reverse DCF**  
Record the October 30 quote, values at beta 1.0, measured beta and adjusted beta, and the implied growth path. Identify your forecast sources and assumptions.

**Bear case**  
What changes in growth and margins? Record base upside, bear downside and their ratio.

**Quality and risk**  
Record Piotroski, Beneish, 60-month risk measures, worst full calendar year and the mechanical ceiling. Identify each MISSING component.

**Dip test**  
What dated fact supports your explanation? What evidence would distinguish a temporary problem from a deteriorating business?

**Price versus evidence**  
What does the current price imply? Write your own conclusion.

**Laura fit and portfolio overlap**  
Review the cash-flow floor, industry exposure and potential overlap. Write your own conclusion.

## Company 3

**Ticker, listing and WInS eligibility**  
Your notes

**Business, ten-year plan and competitors**  
Which reported driver matters most, and what would a competitor do to challenge it?

**DCF and reverse DCF**  
Record the October 30 quote, values at beta 1.0, measured beta and adjusted beta, and the implied growth path. Identify your forecast sources and assumptions.

**Bear case**  
What changes in growth and margins? Record base upside, bear downside and their ratio.

**Quality and risk**  
Record Piotroski, Beneish, 60-month risk measures, worst full calendar year and the mechanical ceiling. Identify each MISSING component.

**Dip test**  
What dated fact supports your explanation? What evidence would distinguish a temporary problem from a deteriorating business?

**Price versus evidence**  
What does the current price imply? Write your own conclusion.

**Laura fit and portfolio overlap**  
Review the cash-flow floor, industry exposure and potential overlap. Write your own conclusion.
