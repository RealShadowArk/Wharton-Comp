"""Compute the kit's annual red-flag tests from frozen SEC CompanyFacts."""
import csv
import json
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CUTOFF = "2026-10-31"
ANNUAL = {"10-K", "20-F"}
TICKERS = "ADBE CRM INTU NOW SAP ADSK NKE EL UL DEO PEP KO".split()
MISSING = "MISSING"

GAAP = {
    "sales": ("RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues", "SalesRevenueNet"),
    "ni": ("ProfitLoss", "NetIncomeLoss"),
    "continuing_ni": ("IncomeLossFromContinuingOperations",),
    "cfo": ("NetCashProvidedByUsedInOperatingActivities",),
    "ca": ("AssetsCurrent",), "cl": ("LiabilitiesCurrent",),
    "assets": ("Assets",), "lt_debt": ("LongTermDebtNoncurrent",),
    "gross": ("GrossProfit",),
    "ar": ("AccountsReceivableNetCurrent",),
    "ppe": ("PropertyPlantAndEquipmentNet",),
    "dep": ("Depreciation", "DepreciationNonproduction", "DepreciationPremisesAndEquipment"),
    "sga": ("SellingGeneralAndAdministrativeExpense",),
    "shares": ("CommonStockSharesOutstanding",),
}
IFRS = {
    "sales": ("Revenue",), "ni": ("ProfitLoss",),
    "continuing_ni": ("ProfitLossFromContinuingOperations",),
    "cfo": ("CashFlowsFromUsedInOperatingActivities",),
    "ca": ("CurrentAssets",), "cl": ("CurrentLiabilities",),
    "assets": ("Assets",), "lt_debt": ("NoncurrentBorrowings",),
    "gross": ("GrossProfit",),
    "ar": ("TradeReceivables", "CurrentTradeReceivables"),
    "ppe": ("PropertyPlantAndEquipment",),
    "dep": ("DepreciationPropertyPlantAndEquipment",),
    "sga": ("SellingGeneralAndAdministrativeExpense",),
    "shares": ("NumberOfSharesOutstanding",),
}
STOCK = {"ca", "cl", "assets", "lt_debt", "ar", "ppe", "shares"}
NO_SHARE_TEST = {"NOW", "UL", "EL"}
DEO_URL = "https://www.sec.gov/Archives/edgar/data/835403/000162828026057527/dia045-arax2026annualrep.htm"
DEO_ROWS = {
    "sales": ((19643, 20245), "2246, consolidated net sales after excise duties"),
    "ni": ((1958, 2538), "2246, consolidated profit for the year"),
    "gross": ((11681, 12173), "2246, consolidated gross profit"),
    "cfo": ((4392, 4297), "213 and 3202, consolidated net cash from operating activities"),
    "ca": ((17212, 17497), "2261, consolidated current assets"),
    "cl": ((10730, 10712), "2261, consolidated current liabilities"),
    "assets": ((46845, 49322), "2261, consolidated total assets"),
    "lt_debt": ((19062, 20820), "2261, non-current borrowings"),
    "ar": ((2596, 2789), "2716, note 15(b) current trade receivables"),
    "ppe": ((8996, 9528), "2261, consolidated property, plant and equipment"),
    "dep": ((668, 654), "2608, property and equipment depreciation charge, with combined exceptional depreciation and impairment excluded"),
    "continuing_ni": ((1958, 2538), "2246, consolidated income statement presents no discontinued-operations result"),
    "shares": ((2224, 2222), "2993 and 2871, issued ordinary shares less own shares, in millions"),
}
F_TESTS = ("positive_roa", "positive_cfo", "higher_roa", "cfo_gt_ni", "lower_debt_ratio",
           "higher_current_ratio", "no_net_share_increase", "higher_gross_margin",
           "higher_asset_turnover")
B_TESTS = ("DSRI", "GMI", "AQI", "SGI", "DEPI", "SGAI", "TATA", "LVGI")

def day(s):
    return date.fromisoformat(s)

def eligible(x):
    return x.get("form") in ANNUAL and x.get("fp") == "FY" and x.get("end", "") <= x.get("filed", "") <= CUTOFF

def choose_periods(facts, expected):
    observations = [(x, unit) for unit, xs in facts.get("Assets", {}).get("units", {}).items()
                    for x in xs if eligible(x) and not x.get("start")
                    and 0 <= (day(x["filed"]) - day(x["end"])).days <= 180]
    recent = max((x["end"] for x, _ in observations), default=None)
    if not recent or (expected and recent != expected):
        return None
    filed = max(x["filed"] for x, _ in observations if x["end"] == recent)
    refs = {(x["accn"], u) for x, u in observations if x["end"] == recent and x["filed"] == filed}
    if len(refs) != 1:
        return None
    accn, unit = refs.pop()
    ends = [recent]
    for _ in range(2):
        prev = {x["end"] for x, u in observations if u == unit
                and 350 <= (day(ends[-1]) - day(x["end"])).days <= 380}
        if len(prev) != 1:
            return None
        ends.append(prev.pop())
    return ends, unit, accn, filed

def pick(facts, tags, unit, end, accn, start=None, fallback=False):
    for tag in tags:
        rows = [x for x in facts.get(tag, {}).get("units", {}).get(unit, [])
                if eligible(x) and x.get("end") == end and x.get("start") == start
                and (x["accn"] == accn or fallback and (day(x["filed"]) - day(end)).days <= 180)]
        preferred = [x for x in rows if x["accn"] == accn]
        if preferred:
            rows = preferred
        if not rows:
            continue
        filed = max(x["filed"] for x in rows)
        rows = [x for x in rows if x["filed"] == filed]
        if len({(x["accn"], x["val"]) for x in rows}) != 1:
            return None
        return dict(rows[0], tag=tag, unit=unit)
    return None

def divide(a, b):
    if not b:
        raise ZeroDivisionError
    return a / b

def run_company(ticker, expected):
    body = json.loads((ROOT / "sec_facts" / f"{ticker}.json").read_text(encoding="utf-8-sig"))["body"]
    ns = "ifrs-full" if ticker in {"SAP", "UL", "DEO"} else "us-gaap"
    facts = body["facts"][ns]
    tags = IFRS if ns == "ifrs-full" else GAAP
    output = {"ticker": ticker, "fiscal_end_t": MISSING, "fiscal_end_t1": MISSING,
              "fiscal_end_t2": MISSING, "reporting_currency": MISSING,
              "annual_filed": MISSING, "annual_filing_index": MISSING}
    dates = (["2026-06-30", "2025-06-30", "2024-06-30"], "USD", "0001628280-26-057529",
             "2026-08-18") if ticker == "DEO" else choose_periods(facts, expected)
    if not dates:
        output.update(dict.fromkeys((*F_TESTS, *B_TESTS, "piotroski", "beneish"), MISSING))
        return output, [], ["Annual period anchors missing or inconsistent."]
    ends, currency, accn, filed = dates
    index = f"https://www.sec.gov/Archives/edgar/data/{body['cik']}/{accn.replace('-', '')}/{accn}-index.htm"
    output.update(zip(("fiscal_end_t", "fiscal_end_t1", "fiscal_end_t2", "reporting_currency",
                       "annual_filed", "annual_filing_index"), (*ends, currency, filed, index)))
    evidence = []
    values = {}
    def record(item, i, tag, amount, url, filed_date=filed, accession=accn, unit=currency, taxonomy=ns):
        start = "" if item in STOCK else (day(ends[i+1]) + timedelta(days=1)).isoformat()
        evidence.append(dict(ticker=ticker, input=item, period=f"t-{i}", taxonomy=taxonomy,
                             tag=tag, unit=unit, start=start, end=ends[i], filed=filed_date,
                             accession=accession, value=amount, url=url))

    for item, concepts in tags.items():
        periods = range(3) if item == "assets" else range(2)
        for i in periods:
            start = None if item in STOCK else (day(ends[i+1]) + timedelta(days=1)).isoformat()
            if ticker == "DEO" and i < 2:
                if item in DEO_ROWS:
                    amounts, locator = DEO_ROWS[item]
                    values[item, i] = amounts[i] * 1_000_000
                    record(item, i, locator, values[item, i], DEO_URL, accession="0001628280-26-057527",
                           unit="shares" if item == "shares" else currency, taxonomy="SEC annual report, EX-99")
                continue
            if item == "shares" and ticker in NO_SHARE_TEST:
                continue
            if item == "lt_debt":
                if ticker == "ADBE":
                    concepts = ("LongTermDebt",)
                if ticker == "ADSK":
                    concepts = ("LongTermNotesPayable",)
            if ticker == "CRM" and item == "ppe":
                concepts = ("PropertyPlantAndEquipmentAndFinanceLeaseRightOfUseAssetAfterAccumulatedDepreciationAndAmortization",)
            row = pick(facts, concepts, "shares" if item == "shares" else currency,
                       ends[i], accn, start, fallback=item == "assets" and i == 2)
            if row:
                evidence.append(dict(ticker=ticker, input=item, period=f"t-{i}", taxonomy=ns,
                                     tag=row["tag"], unit=row["unit"], start=row.get("start", ""),
                                     end=row["end"], filed=row["filed"], accession=row["accn"],
                                     value=row["val"], url=f"https://www.sec.gov/Archives/edgar/data/{body['cik']}/{row['accn'].replace('-', '')}/{row['accn']}-index.htm"))
                values[item, i] = row["val"]
    if ticker == "NOW":
        now_url = "https://www.sec.gov/Archives/edgar/data/1373715/000137371526000007/now-20251231.htm"
        for item, amounts, locator, unit in (
            ("shares", (1047278000, 1032437000), "2021, year-end outstanding shares on same post-split basis", "shares"),
            ("lt_debt", (1491000000, 1489000000), "2015, long-term debt, net", "USD"),
        ):
            for i, amount in enumerate(amounts):
                values[item, i] = amount
                record(item, i, locator, amount, now_url, unit=unit, taxonomy="10-K statement")
    if ticker in {"ADBE", "NOW"}:
        url, locator, amounts = (
            ("https://www.sec.gov/Archives/edgar/data/796343/000079634326000003/adbe-20251128.htm",
             "1566–1568", (7130, 5560)) if ticker == "ADBE" else
            ("https://www.sec.gov/Archives/edgar/data/1373715/000137371526000007/now-20251231.htm",
             "2064–2066", (1748, 1425))
        )
        for i, amount in enumerate(amounts):
            values["continuing_ni", i] = amount * 1_000_000
            record("continuing_ni", i, locator + ", net income on consolidated statement without a discontinued-operations result",
                   values["continuing_ni", i], url, taxonomy="10-K statement")
        if ticker == "ADBE":
            for i, amount in enumerate((236, 239)):
                values["dep", i] = amount * 1_000_000
                record("dep", i, "2392, depreciation and amortization expense limited to property and equipment",
                       values["dep", i], url, taxonomy="10-K note")
    for i in range(2):
        start = (day(ends[i+1]) + timedelta(days=1)).isoformat()
        if ticker in {"ADBE", "CRM", "INTU", "NOW", "ADSK", "SAP"} and ("sga", i) not in values:
            split = ("SalesAndMarketingExpense", "AdministrativeExpense") if ticker == "SAP" else (
                "SellingAndMarketingExpense", "GeneralAndAdministrativeExpense")
            parts = [pick(facts, (tag,), currency, ends[i], accn, start) for tag in split]
            if all(parts):
                values["sga", i] = sum(part["val"] for part in parts)
                for part in parts:
                    record("sga", i, part["tag"], part["val"], index)
    def v(item, period=0):
        return values[item, period]
    def ratio(a, b, period):
        return divide(v(a, period), v(b, period))
    def margin(period):
        return ratio("gross", "sales", period)
    def asset_quality(period):
        return 1 - divide(v("ca", period) + v("ppe", period), v("assets", period))
    def depreciation_rate(period):
        return divide(v("dep", period), v("dep", period) + v("ppe", period))
    def leverage(period):
        return divide(v("cl", period) + v("lt_debt", period), v("assets", period))
    def debt_ratio(period):
        average = (v("assets", period) + v("assets", period+1)) / 2
        return divide(v("lt_debt", period), average)
    def roa(period):
        return divide(v("ni", period), v("assets", period+1))
    def turnover(period):
        return divide(v("sales", period), v("assets", period+1))
    tests = {
        "positive_roa": lambda: roa(0) > 0, "positive_cfo": lambda: v("cfo") > 0,
        "higher_roa": lambda: roa(0) > roa(1), "cfo_gt_ni": lambda: v("cfo") > v("ni"),
        "lower_debt_ratio": lambda: debt_ratio(0) < debt_ratio(1),
        "higher_current_ratio": lambda: ratio("ca", "cl", 0) > ratio("ca", "cl", 1),
        "no_net_share_increase": lambda: v("shares") <= v("shares", 1),
        "higher_gross_margin": lambda: margin(0) > margin(1),
        "higher_asset_turnover": lambda: turnover(0) > turnover(1),
        "DSRI": lambda: divide(ratio("ar", "sales", 0), ratio("ar", "sales", 1)),
        "GMI": lambda: divide(margin(1), margin(0)),
        "AQI": lambda: divide(asset_quality(0), asset_quality(1)),
        "SGI": lambda: divide(v("sales"), v("sales", 1)),
        "DEPI": lambda: divide(depreciation_rate(1), depreciation_rate(0)),
        "SGAI": lambda: divide(ratio("sga", "sales", 0), ratio("sga", "sales", 1)),
        "TATA": lambda: divide(v("continuing_ni") - v("cfo"), v("assets")),
        "LVGI": lambda: divide(leverage(0), leverage(1)),
    }
    notes = []
    for name, test in tests.items():
        try:
            value = test()
            output[name] = int(value) if isinstance(value, bool) else value
        except (KeyError, ZeroDivisionError) as exc:
            output[name] = MISSING
            notes.append(f"{name}: {exc.args[0] if exc.args else 'zero denominator'}")
    known_f = [output[name] for name in F_TESTS if output[name] != MISSING]
    output["f_checked"] = len(known_f)
    output["f_passes_known"] = sum(known_f)
    output["piotroski"] = sum(known_f) if len(known_f) == 9 else MISSING
    coefficients = (.920, .528, .404, .892, .115, -.172, 4.679, -.327)
    output["beneish"] = (-4.84 + sum(c * output[n] for c, n in zip(coefficients, B_TESTS))
                         if all(output[n] != MISSING for n in B_TESTS) else MISSING)
    output["piotroski_flag"] = MISSING if output["piotroski"] == MISSING else int(output["piotroski"] <= 3)
    output["beneish_flag"] = MISSING if output["beneish"] == MISSING else int(output["beneish"] > -1.78)
    if ticker in NO_SHARE_TEST and ("shares", 0) not in values:
        notes.append("Share test withheld pending split, share-class or comparable outstanding-count check.")
    return output, evidence, notes

def main():
    periods = {}
    for path in [ROOT / "software" / "Software.csv", *sorted((ROOT / "consumer").glob("*.csv"))]:
        with path.open(encoding="utf-8-sig", newline="") as f:
            periods.update({r["ticker"]: r["fy_end_date"] for r in csv.DictReader(f)
                            if r.get("ticker") and r.get("fy_end_date")})
    reports, facts, notes = [], [], []
    for ticker in TICKERS:
        result, evidence, missing = run_company(ticker, periods.get(ticker))
        reports.append(result)
        facts.extend(evidence)
        notes.append({"ticker": ticker, "notes": missing})
    cols = list(reports[0])
    for name, rows, fields in (("red_flags.csv", reports, cols),
                               ("fact_locators.csv", facts, list(facts[0]))):
        with (HERE / name).open("w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fields, restval=MISSING)
            w.writeheader()
            w.writerows(rows)
    (HERE / "missing_notes.json").write_text(json.dumps(notes, indent=2) + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()
