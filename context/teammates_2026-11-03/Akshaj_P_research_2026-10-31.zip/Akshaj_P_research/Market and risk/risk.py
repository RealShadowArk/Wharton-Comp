import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SYMBOLS = "ADBE CRM INTU NOW SAP ADSK NKE EL UL DEO PEP KO".split()
RF = 0.04
RF_SOURCE = "https://fred.stlouisfed.org/data/DTB3"


def read_rows(name):
    with (ROOT / name).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_rows(name, header, rows):
    with (ROOT / name).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)


def month_label(number):
    year, month0 = divmod(number, 12)
    return f"{year:04}-{month0 + 1:02}"


def main():
    monthly = defaultdict(dict)
    for row in read_rows("monthly_adjusted.csv"):
        monthly[row["symbol"]][row["month"]] = float(row["adj_close"])
    sources = {(r["symbol"], r["interval"]): r["source_url"] for r in read_rows("market_sources.csv")}
    last = 2026 * 12 + 9
    months = [month_label(i) for i in range(last - 60, last + 1)]
    benchmark = [monthly["SPY"][key] for key in months]
    market_return = benchmark[-1] / benchmark[0]
    market_return = market_return ** (1 / 5) - 1
    market_returns = [new / old - 1 for old, new in zip(benchmark, benchmark[1:])]
    summaries = []
    return_rows = []
    annual_rows = []
    for symbol in SYMBOLS:
        history = monthly[symbol]
        worst = None
        for year in range(int(min(history)[:4]) + 1, 2026):
            anchors = [f"{year-1}-12"] + [f"{year}-{m:02}" for m in range(1, 13)]
            if all(key in history for key in anchors):
                result = history[anchors[-1]] / history[anchors[0]] - 1
                annual_rows.append([symbol, year, history[anchors[0]], history[anchors[-1]], result])
                if worst is None or result < worst[1]:
                    worst = (year, result)
        if not all(key in history for key in months):
            metrics = ["MISSING"] * 8
        else:
            prices = [history[key] for key in months]
            returns = [new / old - 1 for old, new in zip(prices, prices[1:])]
            beta = statistics.linear_regression(market_returns, returns).slope
            vol = statistics.stdev(returns) * math.sqrt(12)
            annual = (prices[-1] / prices[0]) ** (1 / 5) - 1
            sharpe = (annual - RF) / vol if vol else "MISSING"
            treynor = (annual - RF) / beta if beta else "MISSING"
            alpha = annual - (RF + beta * (market_return - RF))
            metrics = [60, beta, 0.67 * beta + 0.33, vol, annual, sharpe, treynor, alpha]
            for key, price, mrk, ret, mrkret in zip(months[1:], prices[1:], benchmark[1:], returns, market_returns):
                return_rows.append([symbol, key, price, mrk, ret, mrkret])
        worst_year, worst_return = worst if worst else ("MISSING", "MISSING")
        ceiling = 6000 / -worst_return if worst and worst_return < 0 else "MISSING"
        summaries.append([symbol, months[0], months[-1], *metrics, market_return, RF, "2026-10-29", worst_year, worst_return, ceiling, sources[(symbol, "1mo")], sources[("SPY", "1mo")], RF_SOURCE])
    write_rows("risk_metrics.csv", ["ticker", "first_price_month", "last_price_month", "monthly_return_count", "beta", "adjusted_beta", "annualized_sample_volatility", "stock_cagr", "sharpe", "treynor", "alpha", "spy_cagr", "rf_discount_basis", "rf_observation_date", "worst_full_calendar_year", "worst_calendar_return", "mechanical_ceiling_usd", "stock_source", "benchmark_source", "rf_source"], summaries)
    write_rows("matched_returns.csv", ["ticker", "month", "stock_adj_close", "spy_adj_close", "stock_monthly_return", "spy_monthly_return"], return_rows)
    write_rows("calendar_returns.csv", ["ticker", "year", "prior_december_adj_close", "december_adj_close", "calendar_return"], annual_rows)
    print(f"Risk rows {len(summaries)}. Matched returns {len(return_rows)}. Complete calendar years {len(annual_rows)}.")


if __name__ == "__main__":
    main()
