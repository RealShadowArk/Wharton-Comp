import csv
import json
import math
import statistics as st
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "market_raw"
RAW.mkdir(exist_ok=True)
SYMBOLS = "SPY VOO ADBE CRM INTU NOW SAP SAP.DE ADSK NKE EL UL DEO PEP KO MDLZ ULVR.L UNA.AS DGE.L IGV XLP".split()
END = int(datetime(2026, 11, 1, tzinfo=timezone.utc).timestamp())
DAILY_START = int(datetime(2025, 10, 29, tzinfo=timezone.utc).timestamp())


def fetch(task):
    symbol, interval = task
    start = 0 if interval == "1mo" else DAILY_START
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?period1={start}&period2={END}&interval={interval}&events=history&includeAdjustedClose=true"
    path = RAW / f"{symbol}_{interval}.json"
    if path.exists():
        saved = json.loads(path.read_text(encoding="utf-8"))
    else:
        request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(request, timeout=18) as response:
            body = json.load(response)
        saved = {"url": url, "read_utc": datetime.now(timezone.utc).isoformat(), "body": body}
        path.write_text(json.dumps(saved), encoding="utf-8")
    result = saved["body"]["chart"]["result"][0]
    meta = result["meta"]
    if meta["symbol"] != symbol or meta["dataGranularity"] != interval:
        raise ValueError(f"Unexpected series for {symbol} {interval}")
    zone = ZoneInfo(meta["exchangeTimezoneName"])
    timestamps = result["timestamp"]
    quotes = result["indicators"]["quote"][0]
    adjusted = result["indicators"]["adjclose"][0]["adjclose"]
    if not (len(timestamps) == len(quotes["close"]) == len(adjusted)):
        raise ValueError("Quote and adjusted-close array mismatch")
    rows = []
    for index, stamp in enumerate(timestamps):
        date = datetime.fromtimestamp(stamp, zone).date().isoformat()
        if date <= "2026-10-31":
            rows.append((date, quotes["close"][index], adjusted[index], quotes["high"][index]))
    return (symbol, interval), (saved, meta, rows)


def write_csv(name, header, rows):
    with (ROOT / name).open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)


def main():
    data = {}
    with ThreadPoolExecutor(max_workers=3) as executor:
        tasks = {(s, i): executor.submit(fetch, (s, i)) for s in SYMBOLS for i in ("1d", "1mo")}
        for task, future in tasks.items():
            try:
                key, result = future.result()
                data[key] = result
            except Exception as exc:
                print(*task, repr(exc), flush=True)
    manifest = []
    monthly = {}
    daily = []
    monthly_rows = []
    for (symbol, interval), (saved, meta, rows) in data.items():
        manifest.append([symbol, interval, meta["currency"], saved["url"], saved["read_utc"], len(rows)])
        if interval == "1mo":
            vals = {}
            for date, close, adj, high in rows:
                if adj is not None and adj > 0:
                    month = date[:7]
                    if month in vals:
                        if not math.isclose(vals[month], adj, rel_tol=1e-6):
                            print(symbol, month, "conflicting monthly values; check raw feed", flush=True)
                            vals[month] = None
                        continue
                    vals[month] = adj
            monthly[symbol] = {key: value for key, value in vals.items() if value is not None}
            monthly_rows.extend([symbol, month, value, meta["currency"]] for month, value in sorted(monthly[symbol].items()))
        else:
            valid = [row for row in rows if row[1] is not None]
            if not valid or valid[-1][0] != "2026-10-30":
                print(symbol, "Oct 30 regular close unavailable", flush=True)
                continue
            date, close, adj, _ = valid[-1]
            highs = [h for d, _, _, h in valid if d >= "2025-10-31" and h is not None]
            start = next((a for d, _, a, _ in valid if d == "2025-10-30"), None)
            high = max(highs) if highs else None
            daily.append([symbol, date, meta["currency"], close, st.mean(x[1] for x in valid[-200:]) if len(valid) >= 200 else "MISSING", high, 1-close/high if high else "MISSING", adj/start-1 if adj and start else "MISSING", saved["url"], saved["read_utc"]])
    write_csv("market_sources.csv", ["symbol", "interval", "currency", "source_url", "retrieved_utc", "rows"], manifest)
    write_csv("monthly_adjusted.csv", ["symbol", "month", "adj_close", "currency"], monthly_rows)
    write_csv("oct30_quotes.csv", ["symbol", "observation_date", "currency", "close", "sma200", "high_52wk_intraday", "fraction_below_high", "one_year_adjusted_return", "source_url", "retrieved_utc"], daily)
    print("Downloaded", len(data), "of", len(tasks), "series", flush=True)


if __name__ == "__main__":
    main()
