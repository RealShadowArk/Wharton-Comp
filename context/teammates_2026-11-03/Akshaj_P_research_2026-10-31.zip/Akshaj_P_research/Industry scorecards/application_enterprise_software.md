# Application and enterprise software — industry evidence

**Evidence cutoff October 31, 2026.** The industry covers vendors selling business applications and enterprise software, including subscription and licensed products. The January financial snapshot uses NYU Stern's broader U.S. Software (System & Application) category of 309 firms. IGV is a separate technical proxy for North American software and selected interactive media and services. The broad benchmark is the S&P 500 Index. [NYU industry classification and counts](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/roe.html) · [iShares IGV](https://www.ishares.com/us/products/239771/ishares-north-american-techsoftware-etf?qt=IGV)

## Company research universe

See the separate company evidence sheet for the final unranked candidate set, eligibility and country checks. WInS comparison is MISSING here.

## Industry fundamentals

January 2026 U.S. industry dataset. S&P 500 entries require a comparable date, denominator, coverage and aggregation method. The NYU total U.S. market row is a different universe.

| Measure | Template points available | Software | S&P 500 or requested reference |
|---|---:|---|---|
| ROE | 12.5 | 29.62%, unadjusted. [ROE](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/roe.html) | MISSING |
| Operating margin | 12.5 | 32.98%, pretax and unadjusted. [Margins](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/margin.html?mibextid=kdkkhi) | MISSING |
| Debt/equity | 25 | 51.84% book basis, derived from 34.14% book debt/capital as 34.14 ÷ (100 − 34.14). Unadjusted market-equity D/E was 5.67%. [Debt](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/dbtfund.html) | MISSING |
| Expected five-year earnings growth | 25 | 22.76% in the source's next-five-years field. Forecast coverage and weighting may differ from the benchmark. [PE and growth](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/pedata.html) | MISSING |
| Forward P/E versus industry ten-year average | 8.3 | 34.13× January forward P/E. [PE and growth](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/pedata.html) | MISSING comparable ten-year industry average |
| Price/sales | 8.3 | 11.01×. [Price/sales](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/psdata.html) | MISSING |
| Price/book | 8.3 | 9.14×. [Price/book](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/pbvdata.html) | MISSING |

Points and verdict are left for human review. A missing comparison has no awarded points here.

## Technical evidence

| Measure | Dated evidence |
|---|---|
| October 30, 2026 market close and 200-day SMA | IGV closed at $104.29, about 11.0% above the $93.96 simple average of unadjusted daily market closes. [iShares market close](https://www.ishares.com/us/products/239771/ishares-north-american-techsoftware-etf?qt=IGV) · [Secondary moving-average series](https://movingaveragealerts.com/etf/igv/) |
| October 30, 2026 distance from 52-week high | Approximately 10.3% below StockSetups' $116.32 market high, calculated using the iShares closing price. The secondary page headline shows $104.33 while its embedded chart shows $104.29. [iShares close](https://www.ishares.com/us/products/239771/ishares-north-american-techsoftware-etf?qt=IGV) · [StockSetups dated snapshot](https://stocksetups.com/symbol/IGV) |
| Common-date one-year total return | September 30, 2026 IGV NAV −7.5% versus S&P 500 Index +15.74%, about 23.2 percentage points lower. ETF NAV reflects fund expenses. October-end like-for-like total returns are MISSING. [Schwab fund performance](https://www.schwab.wallst.com/Prospect/Research/etfs/performance.asp?symbol=igv) · [State Street index comparison](https://www.ssga.com/us/en/individual/etfs/state-street-spdr-sp-500-etf-trust-spy) |

## Demand and risk evidence

- **Software budgets.** Gartner's October 21 forecast projects worldwide software spending of $1.464 trillion in 2026 and $1.679 trillion in 2027, up 14.6% in 2027. This is worldwide spending over a short forecast horizon. [Gartner October 21, 2026](https://www.gartner.com/en/newsroom/press-releases/2026-10-21-gartner-forecasts-worldwide-it-spending-to-grow-15-percent-in-2027-totaling-7-point-35-trillion)
- **Cloud migration.** SAP reported €24.144 billion of current cloud backlog in Q3, up 28% reported and 26% in constant currency year over year. This is a company backlog measure. [SAP Q3 statement, October 21, 2026](https://www.sap.com/docs/download/investors/2026/sap-2026-q3-statement.pdf)
- **AI product adoption.** Adobe reported year-over-year growth above 150% in AI-first annual recurring revenue. That rate applies to Adobe's AI-first category. [Adobe Q3 results, September 10, 2026](https://www.adobe.com/cc-shared/assets/investor-relations/pdfs/01906202/au56y4ter.pdf)
- **Legacy sales exposure.** SAP reported lower year-over-year software license and support revenue alongside growth in cloud. Both measures can matter when assessing how migration affects revenue and margins. [SAP Q3 statement, October 21, 2026](https://www.sap.com/docs/download/investors/2026/sap-2026-q3-statement.pdf)
- **Forecast and monetization risk.** Gartner's outlook depends in part on the ability to finance and monetize AI infrastructure. Adobe's AI-first growth rate alone leaves the industrywide effect on operating profit MISSING. [Gartner October 21, 2026](https://www.gartner.com/en/newsroom/press-releases/2026-10-21-gartner-forecasts-worldwide-it-spending-to-grow-15-percent-in-2027-totaling-7-point-35-trillion) · [Adobe September 10, 2026](https://www.adobe.com/cc-shared/assets/investor-relations/pdfs/01906202/au56y4ter.pdf)

**Human review.** AI benefit or threat judgment, final industry verdict and top three remain open. Ten-year demand growth is MISSING.
