# Consumer brands — industry evidence

**Evidence cutoff October 31, 2026.** The company universe spans branded beverages, personal care, household products and discretionary apparel or footwear. XLP is a narrower technical proxy, tracking the consumer-staples segment of the S&P 500. Its mandate excludes discretionary apparel and foreign brands outside the S&P 500. The broad benchmark is the S&P 500 Index. [State Street XLP](https://www.ssga.com/us/en/individual/etfs/state-street-consumer-staples-select-sector-spdr-etf-xlp)

## Company research universe

See the separate company evidence sheet for the final unranked candidate set, eligibility and country checks. WInS comparison is MISSING here.

## Industry fundamentals

The consumer-brand universe spans multiple industries. A pooled comparable series is MISSING. Below are separate January 2026 U.S. sector rows and their original measures. The figures do not define a combined industry average.

| Measure | Template points available | Alcoholic beverages, 14 firms | Soft beverages, 27 firms | Household products, 110 firms | S&P 500 or requested reference |
|---|---:|---:|---:|---:|---|
| ROE, unadjusted | 12.5 | 0.57% | 30.92% | 27.02% | MISSING [ROE](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/roe.html) |
| Operating margin, pretax unadjusted | 12.5 | 22.76% | 20.53% | 18.62% | MISSING [Margins](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/margin.html?mibextid=kdkkhi) |
| Book debt/equity, derived | 25 | 80.02% | 133.64% | 104.33% | MISSING [Debt](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/dbtfund.html) |
| Expected five-year earnings growth | 25 | 3.89% | 15.44% | 8.02% | MISSING [PE and growth](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/pedata.html) |
| Forward P/E versus industry ten-year average | 8.3 | 12.84× | 23.70× | 16.85× | MISSING consistent ten-year averages [PE and growth](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/pedata.html) |
| Price/sales | 8.3 | 1.75× | 3.57× | 2.67× | MISSING [Price/sales](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/psdata.html) |
| Price/book | 8.3 | 1.91× | 6.87× | 5.85× | MISSING [Price/book](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/pbvdata.html) |

Book debt/equity divides the source's book debt/capital by one minus book debt/capital. The three inputs in table order are 44.45%, 57.20%, and 51.06%. [NYU Stern debt, January 2026](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/dbtfund.html)

For proxy context only, State Street's October 30, 2026 estimated three-to-five-year EPS growth was 8.52% for XLP and 21.46% for SPY. These fund estimates use a different universe and horizon from the exact five-year industry comparison. Points and verdict remain open. [State Street XLP](https://www.ssga.com/us/en/individual/etfs/state-street-consumer-staples-select-sector-spdr-etf-xlp) · [State Street SPY](https://www.ssga.com/us/en/individual/etfs/state-street-spdr-sp-500-etf-trust-spy)

## Technical evidence

| Measure | Dated evidence |
|---|---|
| October 30, 2026 market close and 200-day SMA | XLP closed at $89.42, about 5.9% above the $84.46 simple average of unadjusted daily market closes. [State Street market close](https://www.ssga.com/us/en/individual/etfs/state-street-consumer-staples-select-sector-spdr-etf-xlp) · [Secondary moving-average series](https://movingaveragealerts.com/etf/xlp/) |
| October 30, 2026 distance from 52-week high | Closelook's dated price-history series shows XLP 1.1% below its 52-week high. A separately verified intraday 52-week peak is MISSING. [Closelook price history](https://closelook.net/indices/stock/xlp/price-history) |
| Common-date one-year total return | September 30, 2026 XLP NAV +5.59% versus S&P 500 Index +15.74%, or 10.15 percentage points lower. ETF NAV reflects fund expenses. October-end like-for-like total returns are MISSING. [State Street XLP](https://www.ssga.com/us/en/individual/etfs/state-street-consumer-staples-select-sector-spdr-etf-xlp) · [State Street index comparison](https://www.ssga.com/us/en/individual/etfs/state-street-spdr-sp-500-etf-trust-spy) |

## Demand and risk evidence

- **Brand volumes.** Unilever's Power Brands posted 5.8% underlying sales growth and 3.3% volume growth in Q3. These are company portfolio measures. [Unilever Q3, October 28, 2026](https://www.unilever.com/news/press-and-media/press-releases/2026/continued-strong-performance-in-the-third-quarter/)
- **Emerging markets.** Unilever named India, Latin America and Southeast Asia as contributors to quarterly growth. [Unilever Q3, October 28, 2026](https://www.unilever.com/news/press-and-media/press-releases/2026/continued-strong-performance-in-the-third-quarter/)
- **Home-care demand.** Unilever reported home-care underlying volume growth of 5.4%, with double-digit sales growth in fabric cleaning. [Unilever Q3, October 28, 2026](https://www.unilever.com/news/press-and-media/press-releases/2026/continued-strong-performance-in-the-third-quarter/)
- **Input costs and pricing.** Unilever attributed its 2.3% group underlying price growth partly to higher commodity costs. This is a reported pricing response. [Unilever Q3, October 28, 2026](https://www.unilever.com/news/press-and-media/press-releases/2026/continued-strong-performance-in-the-third-quarter/)
- **Competition and volume.** Unilever reported a 1.1% underlying volume decline in Foods and pointed to weaker developed-market retail and increased competition in U.S. condiments. [Unilever Q3, October 28, 2026](https://www.unilever.com/news/press-and-media/press-releases/2026/continued-strong-performance-in-the-third-quarter/)

**Human review.** A quantified sector-wide AI effect and ten-year demand growth are MISSING. The AI judgment, industry verdict and top three remain open.
