# AI use record for Akshaj P.

**Session date** November 2, 2026 ET. **Tool** Codex with web research, Yahoo Finance market data, original filings and the team Python kit. **Request** Identify Akshaj's assigned industries, collect factual inputs and help him learn the research method.

**Work performed** Read the team handout and kit. Collected dated market series and filing inputs, prepared two industry evidence scorecards and two unranked peer files, calculated risk and available red-flag measures, and prepared factual valuation drafts and six blank work pages. Ran the original kit's 28 tests and checked peer coverage.

**Human checks pending** Confirm WInS eligibility, confirm accounting-scope adjustments and proposed thresholds, open original sources, resolve missing data, verify spreadsheet and model assumptions, and write your own ranking, forecasts, investment edge, bear reasoning and Laura fit. Record AI use in the team's log before sharing research. [Wharton Global Youth AI policy](https://globalyouth.wharton.upenn.edu/ai-policy/)
