# M12 readiness

The kit needs five complete companies and at least 80% coverage to release a shortlist. Blank numeric input cells mean MISSING. This check reports coverage and missing measures only.

## Application and enterprise software

Primary eight measures **5/6**. Cross-check **5/6**. Default rules include proposed R8. Confirm R8 before relying on any result.

| Candidate | Missing primary measures | Missing cross-check additions |
|---|---|---|
| ADBE | None | None |
| CRM | None | None |
| INTU | None | None |
| NOW | None | None |
| SAP | B1, V1, V2 | PS, PB |
| ADSK | None | None |

With R8 turned off, the primary coverage is **3/6**.

## Consumer brands

Primary eight measures **2/6**. Cross-check **2/6**. Default rules include proposed R8. Confirm R8 before relying on any result.

| Candidate | Missing primary measures | Missing cross-check additions |
|---|---|---|
| NKE | None | None |
| EL | None | None |
| UL | B1, G1, G2, V2 | None |
| DEO | B1, V1, V2 | PS, PB |
| PEP | B1 | None |
| KO | B1 | None |

With R8 turned off, the primary coverage is **1/6**.
