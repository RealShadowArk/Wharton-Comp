# Akshaj P. | Wharton research work packet

Evidence cutoff October 31, 2026. The price snapshot uses October 30 regular closes. Data was retrieved November 2 ET. The team handout assigns **Application and enterprise software** and **Consumer brands** to Akshaj. This packet supplies research and blank decision worksheets for those two industries.

## Start here

1. **Industry scorecards.** Compare each industry with the S&P 500 using quality, leverage, five-year growth and valuation. Each pillar is worth 25 points. The scorecards retain MISSING for incompatible or unavailable comparisons. For context, Vanguard's September 30 S&P 500 index column shows ROE 29.0%, P/B 5.3× and P/E 24.7×. Its dates and definitions do not complete the January software comparisons or supply forward P/E. [Vanguard VOO fact sheet](https://fund-docs.vanguard.com/F0968.pdf)
2. **M12 files.** Six unranked research candidates per industry, each with at least one foreign issuer. Software has ADBE, CRM, INTU, NOW, SAP and ADSK. Consumer has NKE, EL, UL, DEO, PEP and KO. Verify the actual listings and prices in WInS. Check the team’s $2 billion and positive free cash flow screens on the documented basis. Dated market-cap proxies use a dated share count and October 30 close. They can differ from same-day market caps.
3. **Run your peer test.** Copy the two CSVs from M12 into your original kit under inputs/m12. From the kit root, run `python -m m12.run inputs/m12/Software.csv` and `python -m m12.run inputs/m12/M12_peer_data.csv`. Blank numeric fields mean MISSING. The extra borrowings field lets the kit label proposed R8 as a fallback. See M12 readiness for fields to fix. Review the score, cross-check and 32-variant stability output before choosing your three. The handout gives a robustness benchmark of 24 of 32 variants, and the kit tests top-two stability. Keep that separate from the assignment to evaluate three companies.
4. **Round 2.** Pick three per industry and use one work page for each. Each of the 12 candidates has a fact-prefilled M03 draft. Copy the files for your selections to inputs/m03 in your original kit. Finish the missing model inputs, then run `python -m m03.run TICKER`. Save a separate bear-case input. Compare base upside with bear downside and the growth implied by the price with the evidence you can defend. Apply the proposed pass marks only after Pat confirms them. Write the edge and Laura fit in your own words.
5. **Record your work.** Keep your source checks, model assumptions, unresolved data and AI-use entry. Review the evidence before sharing your own written conclusions.

## Formula and data checks

- Enter monetary inputs in millions and share counts in millions. Price stays per share. Align accounting scope, currency and share class. SAP uses SAP.DE EUR, and UL uses UNA.AS EUR for local comparison. Their risk betas use USD ADRs versus SPY. Check whether those betas fit a EUR DCF. Set a supported EUR risk-free rate. The M03 report prints dollar signs by default, so label the SAP and UL outputs in EUR. For Diageo, DEO's October 30 quote is per ADS, which represents four ordinary shares. Reconcile the denominator before comparing per-share values.
- Use the latest annual filing available by the cutoff. Keep annual operating data, balance-sheet bridge, dated market equity and debt used in WACC clearly separated. Check that annual cash, investments and debt use the same bridge date. Treat annual diluted weighted averages and recent quarterly diluted shares as proxies with dates and bases.
- Compare the current and historical growth periods on the same scope. Check the continuing-operations presentation for Unilever and reporting currency change for Diageo. Historical capex, D&A, tax and margin are model anchors. Forecast assumptions need your own support.
- The M03 forecast uses ten entries each for growth, margin, D&A and capex. Reconcile SBC with EBIT and the cash-flow method. If you calibrate D&A from operating cash flow, enter the sourced SBC adjustment. Reported EBIT already includes SBC expense. Check first fiscal cash-flow timing and that terminal growth is below WACC. Treat both blank ASSUMPTION rows and MISSING rows as open items. Review model defaults before running.
- USD DCF drafts use 4.98% DGS10, observed October 29 and released October 30. The October 30 observation was available on November 2. The risk worksheet uses 4.00% DTB3, a three-month bill discount-basis proxy observed October 29, as a constant assumption for the five-year performance ratios. Confirm the risk-free convention with your team. [FRED DGS10](https://fred.stlouisfed.org/data/DGS10) · [FRED DTB3](https://fred.stlouisfed.org/data/DTB3)
- Risk uses 61 USD monthly adjusted closes to form 60 matched returns, November 2021 through October 2026. Beta is the regression slope versus SPY. Adjusted beta is 0.67 × measured beta + 0.33. Volatility is sample monthly standard deviation × √12. Sharpe, Treynor and alpha use the five-year annualized geometric return in this worksheet. The worst year compares successive December adjusted closes with all 12 monthly observations present. It excludes partial listing years and 2026. The $6,000 divided by the absolute worst-year loss is a historical constraint calculation.
- Five Piotroski totals and two Beneish totals have all required components. Read the component fields and source locators. A blank or MISSING composite leaves the test open. A complete score still needs review against the original filing.

## Questions to investigate before Round 2

- At the October 30 close, INTU was about 50% below its 52-week intraday high, NOW about 45%, NKE about 44% and ADBE about 31%. All four closed below their 200-day moving averages. Find dated operating evidence that distinguishes a temporary setback from continued deterioration. The price screen alone cannot establish the cause.
- In the same market data, the one-year adjusted market-price returns were IGV −8.48%, XLP +20.10% and SPY +12.36%. IGV and XLP are technical references with different scopes. XLP is a staples subset and misses discretionary brands such as Nike. Use the source URLs in Market and risk.
- Vanguard's September 30 snapshot reports 39.7% information technology in VOO. None of these 12 candidates appears among its ten largest companies in that snapshot. Check your portfolio’s other holdings and ETF exposure before interpreting the overlap. For each software company, ask whether its AI revenue, cost or capex exposure adds to the risk already described by the team. [Vanguard VOO fact sheet](https://fund-docs.vanguard.com/F0968.pdf)

## Quiz

1. What does Laura need from us, and when? Give amounts and years.
2. Why does each bond mature just before a payment instead of after it?
3. What is the floor, and why does it let us take risk with the rest?
4. What do VOO and VXUS do that the tilts do not? Why does the handout call XLF a hedge?
5. Why is “a great company” insufficient as a reason to buy?
6. The handout’s simplified earnings-multiple example uses about 16% for XLI and 37% for XLK. Which needs more to go right? Explain what those figures represent in the handout.
7. A stock’s worst year was −40%. What is the most the team can put in it under its rule? Show the calculation.
8. Name two things you must never do in this research.
