# Digital platforms | Input provenance

The input file uses the FY2025 annual statements, FY2024 starting assets, FY2022 growth baselines and October 30, 2026 closes. Values are in millions of the reporting currency except EPS and price. The value column uses an explicitly labeled share-count proxy, not an independently verified October market cap. Close is the regular-session price, not dividend-adjusted. Numeric blanks are deliberate, including capitalized software (not required for this peer group) and separate inventory where not used or not disclosed. The filings are linked in the CSV.

| Company | Price history | Reading to check before Round 2 |
| --- | --- | --- |
| Alphabet | [GOOGL](https://stockanalysis.com/stocks/googl/history/) | Class A price used as a proxy for all common classes. Compare actual ETF exposure by issuer. |
| Meta | [META](https://stockanalysis.com/stocks/meta/history/) | Lease debt includes $1,184m finance leases. Separate investments, future leases and current debt in the DCF. |
| Amazon | [AMZN](https://stockanalysis.com/stocks/amzn/history/) | FY2022 diluted EPS was negative; kit cannot produce G2. FY2025 cash FCF was positive; vendor TTM FCF was negative. Confirm the gate date. |
| Netflix | [NFLX](https://stockanalysis.com/stocks/nflx/history/) | EPS and shares use the same split-adjusted basis as the quote. Model content spend and amortization together. |
| MercadoLibre | [MELI](https://stockanalysis.com/stocks/meli/history/) | US legal domicile despite Latin American operations. Finance leases included in reported loans and financial liabilities. Investigate payments float and credit separately. |
| Sea | [SE](https://stockanalysis.com/stocks/se/history/) | NYSE ADS represents one Class A share; Singapore HQ and Cayman domicile. FY2022 diluted EPS was negative. Note 10 discloses $45.402m finance lease liabilities. |
| Booking Holdings | [BKNG](https://stockanalysis.com/stocks/bkng/history/) | Audited FY2025 operating income $8,825m. Finance leases $6m. Book equity is negative. Split-adjusted share count and EPS align with the price. |
| Expedia | [EXPE](https://stockanalysis.com/stocks/expe/history/) | Audited FY2025 operating income $1,871m. Review deferred merchant bookings and any restricted cash. |
| Airbnb | [ABNB](https://stockanalysis.com/stocks/abnb/history/) | Corporate cash excludes funds held on behalf of customers. Share-count proxy values common classes at the Class A price. |
| Trip.com | [9961 HKEX](https://stockanalysis.com/quote/hkg/9961/history/) | HKD 309.80 × [CFETS October 30 CNY central parity](https://www.chinamoney.org.cn/english/bmkcpr/index.html?tab=2) of 0.85594 CNY per HKD. This is a reference fixing. Verify WInS listing; if only the ADS is eligible, recheck the trade quote and ADS terms separately. |

For annual vendor fields, use the corresponding ticker's `financials/income-statement`, `financials/balance-sheet` and `financials/cash-flow-statement` views. Use audited figures where the vendor uses a standardized definition that differs from reported amounts. [Vanguard VOO composition](https://investor.vanguard.com/investment-products/etfs/profile/voo#portfolio-composition) is the place to confirm dated overlap; any current holdings used after the cutoff should be identified as a separate check.
