# Akshat | Round 2 research starter

**Industries** Internet and digital platforms · Pharma and biotech  
**Evidence cutoff** October 31, 2026 · **Team deadline** November 2, 2026, 9 p.m. ET

Choose three candidates per industry after reviewing your Round 1 output. The kit flags its top two plus ties. Record that flag separately from your selection of a third company. The team proposes 24 of 32 shortlist appearances as a stability threshold. Keep the model outputs, factual evidence and your judgments separate.

## Collect and verify the inputs

1. **Freeze the listing and date.** Record ticker, exchange, issuer domicile, financial currency, share class and ADR ratio if applicable, cutoff close and date, market cap basis, and WInS ticker, tradeability and USD-equivalent price check. The last trading day on or before the research cutoff is the price date if the local exchange was open. Confirm live simulator eligibility separately, with a timestamp. Compare value and price in the same currency and per-share basis.
2. **Build the fiscal table.** Record latest full fiscal year (t), prior year (t-1), and opening assets for t-1 from the t-2 balance sheet. For both years collect revenue, cost of revenue or disclosed gross profit, SG&A, net income, continuing-operations income, operating cash flow, receivables, current assets and liabilities, closing assets, net PP&E, depreciation, long-term debt and actual period-end shares on a comparable split basis. Record exact line labels, fiscal end, publication date, units and source page. Separate depreciation from amortization where the filings disclose it. Use consistent comparative figures and note restatements, spin-offs or large acquisitions.
3. **Build the valuation table.** Collect diluted weighted-average shares, D&A, SBC, capex, interest expense and interest income, corporate cash, borrowing debt and finance leases. Exclude customer or merchant assets from corporate cash and document the scope. Cross-check that lease liabilities appear only once in debt. Record management's latest published guidance, guidance period and measure, and analyst revenue forecasts by fiscal year, forecast date and consensus source where available. An actual result, company target and analyst estimate are separate records. Capture the dated same-currency 10-year government yield and a separate 3-month T-bill yield for the risk calculations.
4. **Record evidence.** For every item keep `field | exact reported label | value | currency/unit | period/as-of date | publication date | link/page | notes`. Use filings and investor releases for company data. For a verified calculation, keep each raw input and the arithmetic. Record MISSING and its reason in your notes when an input cannot be verified. Leave numeric kit CSV cells empty when missing.

## Run and audit the valuation

- From the extracted kit, copy `inputs/m03/TEMPLATE_dcf_inputs.csv` to `inputs/m03/<TICKER>_dcf_inputs.csv`. Confirm each field's units against the template. The forecast paths for `growth`, `ebit_margin`, `da_pct` and `capex_pct` each take 10 decimals separated by semicolons. Use your research to set the base case and save your bear assumptions separately as `<TICKER>bear_dcf_inputs.csv`.
- Use `beta=1.0` as the common reference and put your calculated beta in `beta_measured`. The adjusted beta is `0.67 × measured beta + 0.33`. Use `sbc_pct = SBC / revenue` when D&A is calibrated from cash flow. With directly reported D&A and SBC already expensed in EBIT, follow the template's zero adjustment to avoid double counting and still record actual SBC/revenue on your one-pager. The pretax proxy needs the kit's net-interest adjustment. Remove that adjustment row when input margins are already EBIT. Replace stale sample yields with verified cutoff inputs.
- Run `python -X utf8 -m m03.run <TICKER>` and `python -X utf8 -m m03.run <TICKER>bear`. Read the Markdown and CSV in `outputs/`, including data gaps. Windows may fail to write the Markdown without UTF-8 mode. The report labels currency as USD even when the numerical inputs use a different currency. Verify and label the actual currency before citing results. The helper named in the kit for creating M03 inputs is absent, so use the template directly.
- Compare base value and price at beta 1.0 and at measured beta. Record the adjusted-beta result as sensitivity. Compare implied growth and guidance over comparable horizons and note the implied margin assumptions. With a consistent beta for base and bear, use `upside = base value / price − 1` and `downside = 1 − bear value / price`. Divide only if upside and downside are both positive. Otherwise record each value separately and explain why the ratio is unavailable. Pat decides the proposed thresholds.

## Check fiscal red flags

Piotroski gives one point for each passing test. A missing or unusable input makes the test **Not checked**. Report how many tests were checked, and report a definitive score out of nine only when all are checked.

| Test | Calculation or comparison |
|---|---|
| 1 | `ROA_t = net income_t / beginning assets_t` is positive |
| 2 | `CFO_t > 0` |
| 3 | `ROA_t > ROA_t-1` |
| 4 | `CFO_t > net income_t` |
| 5 | `LT debt / AVERAGE(beginning assets, ending assets)` fell |
| 6 | `current assets / current liabilities` rose |
| 7 | Comparable split-adjusted period-end shares outstanding stayed flat or fell |
| 8 | `gross profit / revenue` rose |
| 9 | `revenue / beginning assets` rose |

| Beneish component | Calculation |
|---|---|
| DSRI | `(receivables / sales)_t / (receivables / sales)_t-1` |
| GMI | `gross margin_t-1 / gross margin_t` |
| AQI | `[1 − (current assets + net PP&E) / assets]_t / same_t-1` |
| SGI | `sales_t / sales_t-1` |
| DEPI | `[depreciation / (depreciation + net PP&E)]_t-1 / same_t` |
| SGAI | `(SG&A / sales)_t / (SG&A / sales)_t-1` |
| TATA | `(continuing-operations income_t − CFO_t) / closing assets_t` |
| LVGI | `[(current liabilities + LT debt) / closing assets]_t / same_t-1` |

`M = −4.84 + 0.920 DSRI + 0.528 GMI + 0.404 AQI + 0.892 SGI + 0.115 DEPI − 0.172 SGAI + 4.679 TATA − 0.327 LVGI`

If the issuer lacks a usable gross-profit line, follow the kit and mark GMI MISSING. If any component is missing or undefined, mark the model Not checked. Flag scores above −1.78 for review. A score is a screening signal.

## Measure historical risk and test the dip

1. **Align the return series.** Use 61 consecutive, completed month-end adjusted closes to get 60 paired returns. Use one common window and record dates. The team's earlier workbook used September 2021 through September 2026 and SPY adjusted close as its S&P 500 proxy. Keep benchmark and stock returns in the same investor currency. Use the WInS USD listing if appropriate, or convert home prices at dated monthly FX rates. Document any listing switches, gaps and currency conversions. Use `r = adjusted close / previous adjusted close − 1`. Report shorter listing history as a gap rather than padding it.
2. **Calculate the risk statistics.** With matched monthly returns, beta is `SLOPE(stock_returns, benchmark_returns)`. Volatility is `STDEV.S(stock_returns) × SQRT(12)`. Compound each series to annual return using `[PRODUCT(1 + monthly_returns)]^(12 / number_of_months) − 1` and document that convention. With the team's dated annual 3-month T-bill yield as `rf`, Sharpe is `(stock annual return − rf) / volatility`, Treynor is `(stock annual return − rf) / beta`, and alpha is `stock annual return − [rf + beta × (benchmark annual return − rf)]`. Flag zero volatility or zero beta as undefined, and flag near-zero or negative beta for interpretation.
3. **Calculate the loss limit.** Verify the worst completed calendar year across the available history on the documented listing and return basis. Exclude partial years and check vendor outliers for splits or ticker changes. For a verified negative worst return, `max dollar position = 6000 / ABS(worst return as a decimal)`. Record the year, start/end history coverage, listing, return basis and source. Missing or nonnegative worst return leaves this sizing test unresolved.
4. **Measure the dip.** Use split-consistent daily prices for the same listing through the cutoff. Record whether the 52-week peak is an intraday high or a closing high. Calculate `% below peak = 1 − cutoff close / 52-week peak`, `% vs 200-day = cutoff close / AVERAGE(last 200 daily closes) − 1`, and one-year total return from consistently adjusted closing prices. Keep the cutoff price used for the DCF on its actual closing-price basis.
5. **Investigate the cause.** Note the peak date, selloff dates and the specific disclosure or event. Compare stock, peer and benchmark returns over the same dates. Look for revisions to guidance, market-share trends, capital intensity and persistent margin or cash-flow weakness. For pharma, check trial endpoints, regulator decisions, patent expiry and pipeline concentration. For platforms, check traffic, pricing, ad growth, regulation, capex and evidence of AI monetization or substitution. Record evidence for both a temporary and lasting cause, then write your own conclusion and the next data point that would overturn it.

## Six company records

Use the same field order in each slot. Add sources and dates to each record as you work. Put your own words in the business description, positives and negatives, edge, rank and fit sections. Fill Laura fit last. Separate the company's contribution to growth from the Treasury reserve's role in funding the payments.

### Internet and digital platforms | Slot 1

- **Snapshot** Ticker / exchange / domicile / dated price / market cap / WInS check ____
- **Round 1** M12 score / rank of group size / kit shortlist flag / stability out of 32 / video cross-check score and rank ____
- **DCF** Value/price at beta 1.0 / measured / adjusted ____
- **Reverse DCF** Growth implied by price / guidance and period / SBC % of revenue ____
- **Bear case** Value/price / assumptions / upside-to-downside ratio ____
- **Red flags** Piotroski score and coverage / Beneish score or missing components ____
- **Risk** Beta / volatility / Sharpe / Treynor / alpha / worst year and loss / maximum position ____
- **Business and plan** Two-sentence description / dated long-term targets and drivers ____
- **Competition** Two rivals / where the company wins and loses ____
- **Dip and technicals** % below 52-week high / cause and evidence / temporary or lasting / vs 200-day average / one-year return ____
- **Portfolio overlap** AI exposure or substitution / VOO top 10 at dated holdings snapshot / other portfolio overlap ____
- **Your assessment** Three positives / three negatives / one-sentence edge / rank and confidence / what would prove you wrong ____
- **Laura fit, written last** Growth role / implications for payment protection / horizon ____
- **Sources and AI-use log** Dated links and pages / AI work performed / what you independently checked ____

### Internet and digital platforms | Slot 2

- **Snapshot** Ticker / exchange / domicile / dated price / market cap / WInS check ____
- **Round 1** M12 score / rank of group size / kit shortlist flag / stability out of 32 / video cross-check score and rank ____
- **DCF** Value/price at beta 1.0 / measured / adjusted ____
- **Reverse DCF** Growth implied by price / guidance and period / SBC % of revenue ____
- **Bear case** Value/price / assumptions / upside-to-downside ratio ____
- **Red flags** Piotroski score and coverage / Beneish score or missing components ____
- **Risk** Beta / volatility / Sharpe / Treynor / alpha / worst year and loss / maximum position ____
- **Business and plan** Two-sentence description / dated long-term targets and drivers ____
- **Competition** Two rivals / where the company wins and loses ____
- **Dip and technicals** % below 52-week high / cause and evidence / temporary or lasting / vs 200-day average / one-year return ____
- **Portfolio overlap** AI exposure or substitution / VOO top 10 at dated holdings snapshot / other portfolio overlap ____
- **Your assessment** Three positives / three negatives / one-sentence edge / rank and confidence / what would prove you wrong ____
- **Laura fit, written last** Growth role / implications for payment protection / horizon ____
- **Sources and AI-use log** Dated links and pages / AI work performed / what you independently checked ____

### Internet and digital platforms | Slot 3

- **Snapshot** Ticker / exchange / domicile / dated price / market cap / WInS check ____
- **Round 1** M12 score / rank of group size / kit shortlist flag / stability out of 32 / video cross-check score and rank ____
- **DCF** Value/price at beta 1.0 / measured / adjusted ____
- **Reverse DCF** Growth implied by price / guidance and period / SBC % of revenue ____
- **Bear case** Value/price / assumptions / upside-to-downside ratio ____
- **Red flags** Piotroski score and coverage / Beneish score or missing components ____
- **Risk** Beta / volatility / Sharpe / Treynor / alpha / worst year and loss / maximum position ____
- **Business and plan** Two-sentence description / dated long-term targets and drivers ____
- **Competition** Two rivals / where the company wins and loses ____
- **Dip and technicals** % below 52-week high / cause and evidence / temporary or lasting / vs 200-day average / one-year return ____
- **Portfolio overlap** AI exposure or substitution / VOO top 10 at dated holdings snapshot / other portfolio overlap ____
- **Your assessment** Three positives / three negatives / one-sentence edge / rank and confidence / what would prove you wrong ____
- **Laura fit, written last** Growth role / implications for payment protection / horizon ____
- **Sources and AI-use log** Dated links and pages / AI work performed / what you independently checked ____

### Pharma and biotech | Slot 1

- **Snapshot** Ticker / exchange / domicile / dated price / market cap / WInS check ____
- **Round 1** M12 score / rank of group size / kit shortlist flag / stability out of 32 / video cross-check score and rank ____
- **DCF** Value/price at beta 1.0 / measured / adjusted ____
- **Reverse DCF** Growth implied by price / guidance and period / SBC % of revenue ____
- **Bear case** Value/price / assumptions / upside-to-downside ratio ____
- **Red flags** Piotroski score and coverage / Beneish score or missing components ____
- **Risk** Beta / volatility / Sharpe / Treynor / alpha / worst year and loss / maximum position ____
- **Business and plan** Two-sentence description / dated long-term targets and drivers ____
- **Competition** Two rivals / where the company wins and loses ____
- **Dip and technicals** % below 52-week high / cause and evidence / temporary or lasting / vs 200-day average / one-year return ____
- **Portfolio overlap** AI exposure or substitution / VOO top 10 at dated holdings snapshot / other portfolio overlap ____
- **Your assessment** Three positives / three negatives / one-sentence edge / rank and confidence / what would prove you wrong ____
- **Laura fit, written last** Growth role / implications for payment protection / horizon ____
- **Sources and AI-use log** Dated links and pages / AI work performed / what you independently checked ____

### Pharma and biotech | Slot 2

- **Snapshot** Ticker / exchange / domicile / dated price / market cap / WInS check ____
- **Round 1** M12 score / rank of group size / kit shortlist flag / stability out of 32 / video cross-check score and rank ____
- **DCF** Value/price at beta 1.0 / measured / adjusted ____
- **Reverse DCF** Growth implied by price / guidance and period / SBC % of revenue ____
- **Bear case** Value/price / assumptions / upside-to-downside ratio ____
- **Red flags** Piotroski score and coverage / Beneish score or missing components ____
- **Risk** Beta / volatility / Sharpe / Treynor / alpha / worst year and loss / maximum position ____
- **Business and plan** Two-sentence description / dated long-term targets and drivers ____
- **Competition** Two rivals / where the company wins and loses ____
- **Dip and technicals** % below 52-week high / cause and evidence / temporary or lasting / vs 200-day average / one-year return ____
- **Portfolio overlap** AI exposure or substitution / VOO top 10 at dated holdings snapshot / other portfolio overlap ____
- **Your assessment** Three positives / three negatives / one-sentence edge / rank and confidence / what would prove you wrong ____
- **Laura fit, written last** Growth role / implications for payment protection / horizon ____
- **Sources and AI-use log** Dated links and pages / AI work performed / what you independently checked ____

### Pharma and biotech | Slot 3

- **Snapshot** Ticker / exchange / domicile / dated price / market cap / WInS check ____
- **Round 1** M12 score / rank of group size / kit shortlist flag / stability out of 32 / video cross-check score and rank ____
- **DCF** Value/price at beta 1.0 / measured / adjusted ____
- **Reverse DCF** Growth implied by price / guidance and period / SBC % of revenue ____
- **Bear case** Value/price / assumptions / upside-to-downside ratio ____
- **Red flags** Piotroski score and coverage / Beneish score or missing components ____
- **Risk** Beta / volatility / Sharpe / Treynor / alpha / worst year and loss / maximum position ____
- **Business and plan** Two-sentence description / dated long-term targets and drivers ____
- **Competition** Two rivals / where the company wins and loses ____
- **Dip and technicals** % below 52-week high / cause and evidence / temporary or lasting / vs 200-day average / one-year return ____
- **Portfolio overlap** AI exposure or substitution / VOO top 10 at dated holdings snapshot / other portfolio overlap ____
- **Your assessment** Three positives / three negatives / one-sentence edge / rank and confidence / what would prove you wrong ____
- **Laura fit, written last** Growth role / implications for payment protection / horizon ____
- **Sources and AI-use log** Dated links and pages / AI work performed / what you independently checked ____

## Before sending your work to Pat

- Attach your two M12 input files, M12 scores and stability outputs, and each base and bear DCF input file. Open the generated valuation reports to confirm the intended ticker, currency and beta variants.
- The M12 runner requires an explicit input path for this kit. It does not validate price dates or derive market caps from shares and prices. Verify these in your evidence log. The stability file summarizes appearances across 32 variants. If operating income is missing in a peer row, check whether the group switched to the kit's pretax fallback before interpreting the result.
- List any missing or stale evidence. For each item record the decision it affects, the source or action that could resolve it, and whether it blocks a conclusion.
- Log what AI helped locate, explain, format or verify, and identify the sources you checked yourself.

**Method references** Team stock research (all parts), Part 4 Template 2. Wharton stock evaluation kit dated October 31, 2026, README stages 2–5, M12 score specification and M03 input template.

