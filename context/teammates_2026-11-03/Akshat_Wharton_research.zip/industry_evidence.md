# Akshat | Industry scorecard evidence

Research cutoff October 31, 2026. The industry table uses the January 2026 US vintage of Damodaran Online. His coverage is broader than the stock shortlist. Use the table as dated industry evidence and put the October market snapshot in a separate comparison column.

| NYU Stern industry proxy | Firms | ROE | Operating margin | Book D/E, derived | Forward P/E | Expected earnings growth, next 5 years | P/S | P/B | Own 10-year forward P/E average |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Software (Internet) | 29 | −1.47% | 3.69% | 149.2% | 64.81× | 20.90% | 8.76× | 10.86× | MISSING |
| Drugs (Pharmaceutical) | 228 | 24.04% | 29.54% | 92.7% | 24.19× | 17.81% | 5.63× | 6.64× | MISSING |
| Drugs (Biotechnology) | 496 | −5.67% | 8.97% | 102.3% | 63.76× | 38.08% | 7.31× | 8.22× | MISSING |
| NYU US Total Market | 5,994 | 17.21% | 12.82% | 161.2% | 27.66× | 13.95% | 3.07× | 4.61× | MISSING |

- ROE and P/B are the columns of those names. Operating margin is pretax, unadjusted. Book D/E is `book debt to capital / (1 − book debt to capital)`, using source inputs of 59.87%, 48.10%, 50.58%, and 61.72%, respectively. Keep this convention separate from the market-value D/E columns in the same source. [ROE and P/B](https://pages.stern.nyu.edu/adamodar/New_Home_Page/datafile/pbvdata.html) · [Operating margins](https://pages.stern.nyu.edu/adamodar/New_Home_Page/datafile/margin.html) · [Debt](https://pages.stern.nyu.edu/adamodar/New_Home_Page/datafile/dbtfund.html) · [Forward P/E and growth](https://pages.stern.nyu.edu/adamodar/New_Home_Page/datafile/pedata.html) · [P/S](https://pages.stern.nyu.edu/adamodar/New_Home_Page/datafile/psdata.html)
- The internet row is a narrow proxy for a shortlist that spans online advertising, commerce, cloud, streaming, and related businesses. Keep the pharmaceutical and biotech lines separate because the industry groups differ in profitability and earnings coverage. The trailing loss-making shares in the NYU P/E dataset are 72.41%, 84.65%, and 89.52% across the three rows, respectively. That matters when interpreting forward multiples and forecast growth. [Industry P/E dataset](https://pages.stern.nyu.edu/adamodar/New_Home_Page/datafile/pedata.html)
- For a January 2026 current reading, the historical column can be calculated from January 2016–January 2025 US annual snapshots. Open the ten source files under “PE Ratios, PEG Ratios and Expected Growth Rates by Industry Sector,” extract the identically named row and forward P/E column, and average the valid observations. Record date, constituents count, metric label and any missing/nonpositive observations. Disclose available sample size and evolving constituents. The archive index was verified and the spreadsheet payloads were unavailable through the browser reader. [NYU archive](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/dataarchived.html)

## S&P 500 comparison

| Input | Verified market reading | Use |
| --- | --- | --- |
| Forward P/E | 18.7×, Oct 30, 2026 (next 12 months) | Market context alongside the dated NYU multiples. Different vintage and aggregation. |
| Market 10-year average forward P/E | 19.1×, Oct 30, 2026 | Compare to the same-source S&P 500 current 18.7×. Each industry needs its own historical series. |
| P/B | 5.62×, Oct 30, 2026, IVV holdings | S&P 500 ETF proxy, with provider methodology and date retained. |
| Matched ROE, pretax unadjusted operating margin, book D/E, five-year EPS growth, and P/S | MISSING | Obtain matched S&P 500 data with dates and definitions from the index/consensus provider or calculate the historical-constituent fundamentals from consistent underlying data. The NYU US Total Market offers same-source reference ratios with different coverage. |

[FactSet S&P 500 earnings update, Oct 30, 2026](https://insight.factset.com/sp-500-earnings-season-update-october-30-2026) · [BlackRock IVV fund characteristics](https://www.blackrock.com/us/individual/products/239726/ishares-core-s-p-500-etf/fund-fact-sheet) · [S&P Dow Jones Indices index scope](https://www.spglobal.com/spdji/en/indices/equity/sp-500/)

## Optional ETF comparisons

FDN tracks the Dow Jones Internet Composite Index. IHE gives US pharmaceuticals exposure and IBB tracks US-listed biotechnology. Their provider-reported one-year NAV total returns to September 30, 2026 were 3.04%, 40.52% and 46.08%, respectively. The S&P 500 total return over the same period was 15.74%, for differences of −12.70, +24.78 and +30.34 percentage points. This is a September 30 comparison. [First Trust performance table](https://www.ftportfolios.com/Retail/etf/etflist.aspx?DisplayType=PerformanceNav&Type=ThematicInternet) · [iShares IHE performance](https://www.ishares.com/us/products/239519/ishares-us-pharmaceuticals-etf?qt=EEMS) · [iShares IBB performance](https://www.ishares.com/us/products/239699/ishares-us-biotechnology-etf) · [State Street S&P 500 benchmark return](https://www.ssga.com/us/en/individual/etfs/state-street-spdr-sp-500-etf-trust-spy)

Template technical checks also need closing price vs its 200-day simple moving average and distance from the 52-week trading high. Use the mean of the latest 200 trading closes and `1 − close / max daily high` over the latest 52 weeks, through October 30. Close inputs were $266.23 FDN, $107.61 IHE, and $217.61 IBB. The full primary daily history and independently calculated averages are MISSING. Use dated fund holdings for overlap by issuer and combine Alphabet share classes before aggregating. [First Trust FDN price history](https://www.ftportfolios.com/retail/etf/ETFpricehistory.aspx?Ticker=FDN) · [IHE trade history](https://finance.yahoo.com/quote/IHE/history/) · [iShares IBB official close](https://www.ishares.com/us/products/239699/ishares-us-biotechnology-etf)
