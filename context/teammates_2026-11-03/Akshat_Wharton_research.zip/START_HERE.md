# Akshat | Wharton research handoff

Your assignments are **Internet and Digital Platforms** and **Pharma and Biotech**. Research snapshot: October 31, 2026; the shared stock close is October 30. Team due date: Monday, November 2 at 9 p.m. ET. Keep a record of anything verified after the snapshot and avoid using later disclosures in snapshot decisions.

## What you are doing

Laura's schedule sets the cash floor. The Treasury ladder is designed to protect the scheduled withdrawals; broad ETFs and tilts diversify the money invested beyond that floor. Your job is to test where individual companies deserve part of the stock allocation. Start with whether an industry is attractive at its price, then compare peers consistently, then test the market price against company evidence. Evaluate Laura fit last, using the case and actual portfolio exposures. A high peer score is a reason to investigate, not a buy signal.

1. Open `Industry_cards.md` and `industry_evidence.md`. The two cards have sourced figures and open inputs. Record source dates and definitions, then check the open items before giving the cards a total. Separate large profitable drug makers from development-stage biotech; likewise distinguish ad, commerce and streaming platforms. A proxy does not measure every company you are screening.
2. Open the two M12 CSVs, confirm WInS instrument and listing, resolve each scope note, and copy approved CSVs into `inputs/m12` inside an extracted copy of the kit. From the kit root run `python -X utf8 -m m12.run inputs/m12/digital_m12_research_inputs.csv` and repeat with `pharma_m12_research_inputs.csv`. Keep the eight measures, four pillars and 32-variant stability result visible. The kit requires at least five complete peers and 80% coverage before releasing a shortlist. A negative EPS endpoint means the CAGR is unsuitable; keep the actual signed EPS in the raw record.
3. Choose three companies per industry yourself after review. The kit's shortlist flag can highlight only two companies unless tied; explain your own third choice. Use `Round_2_starter.md` for six one-page records and fill only with matched, sourced inputs. Start with downside and sizing alongside the DCF, then assess portfolio overlap. Leave decision fields for your own writing.

**Checked in the actual kit:** Digital has 8/10 complete core rows, exactly 80%, before any WInS or other eligibility removals. Amazon and Sea have negative FY2022 EPS, so G2 is unsuitable. Booking's negative common equity also makes ROE and P/B unavailable in the separate cross-check. Pharma has 2/6 complete core rows under the current debt rule. The four IFRS reports disclose aggregate leases; use `pharma_input_provenance.md` to review the exact amounts. Ask Pat to agree on a common debt convention before comparing. Takeda also has a negative ending EPS. Keep the original CSV and document any change to the group, definitions, or eligibility before rerunning.

### Specific checks worth doing

- **Digital platforms:** Compare Alphabet, Meta and Amazon exposure against dated Vanguard VOO holdings, including both listed Alphabet classes, and check current XLK/XLI holdings for direct and business exposure. A stock can add AI risk through demand and investment even when it sits outside the technology sector. Amazon's audited FY2025 simple cash flow after cash capex was positive, but the current vendor trailing-period line shows a negative figure; confirm the FCF gate period with Pat before treating it as eligible. For Netflix, reconcile streaming content additions and amortization together before translating reported margin into sustainable cash flow.
- **MercadoLibre and Sea:** Both have finance businesses alongside platforms. Confirm team scope for diversified issuers with banking or lending operations. MercadoLibre's audited FY2025 operating cash flow included $5,341m from funds payable to customers and $1,592m from payables for card transactions. Sea reported a $474.359m FY2025 change in escrow payables and customer advances in operating cash flow. Separate operating working capital from custody/settlement balances and check the associated assets too before putting cash or cash flow into a DCF. No automatic adjustment is applied in M12.
- **Pharma:** For each selected company, build an expiry and clinical readout timeline from company disclosures, FDA approval and exclusivity records, and patent records. Distinguish a target date from a completed trial or approval. In a bear case, consider one drug losing exclusivity earlier, a trial failure, or reimbursement pressure separately; tie each shock to a specific disclosed product or exposure.
- **WInS:** Public quotes and SEC listing details do not prove simulator eligibility. Search the exact ticker and class in WInS; save the date, currency, displayed price and eligible listing. No orders are needed for this check.

## Quiz

Answer in your own words; I can check the reasoning and point to gaps.

1. What does Laura need from us, and when? Give amounts and years.
2. Why does each bond mature just before a payment, not after?
3. What is the floor, and why does it let us take risk with the rest?
4. What do VOO and VXUS do that the tilts don't? Why is XLF called a hedge?
5. Why isn't “a great company” enough of a reason to buy?
6. XLI's price assumes about 16% earnings growth, XLK's about 37%. Which needs more to go right?
7. A stock's worst year was −40%. What's the most we can put in it? Show the maths.
8. Name two things you must never do in this research.

## Source and AI log

Log the date, tool, task, outputs you used, original sources you checked, and your own decisions. Example activity description: “AI identified role files, collected financial inputs and source links, checked kit readiness, and supplied blank study prompts. I checked the inputs and wrote my own analysis.” See the [Wharton AI policy](https://globalyouth.wharton.upenn.edu/ai-policy/) and [competition rules](https://globalyouth.wharton.upenn.edu/competitions/investment-competition/rules-roles/).
