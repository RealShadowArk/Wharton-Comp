# Industry scorecards | Akshat

Use the [dated evidence sheet](industry_evidence.md) alongside these two cards. Points and conclusions are yours. Leave missing data blank in calculations; a missing input earns neither zero nor a pass. Use the same metric definition and date on both sides. The NYU US Total Market can support a labeled sensitivity comparison, but it is not the S&P 500.

| Check | Points available | Internet proxy | Pharma proxy | Biotech comparator | S&P 500 / reference |
| --- | ---: | ---: | ---: | ---: | --- |
| ROE, higher | 12.5 | −1.47% | 24.04% | −5.67% | MISSING |
| Operating margin, higher | 12.5 | 3.69% | 29.54% | 8.97% | MISSING |
| Book debt/equity, lower | 25 | 149.2% | 92.7% | 102.3% | MISSING |
| Expected 5-year EPS growth, higher | 25 | 20.90% | 17.81% | 38.08% | MISSING |
| Forward P/E vs own 10-year average, lower | 25/3 | 64.81× / MISSING | 24.19× / MISSING | 63.76× / MISSING | 18.7× / 19.1×, Oct 30 context only |
| P/S, lower | 25/3 | 8.76× | 5.63× | 7.31× | MISSING |
| P/B, lower | 25/3 | 10.86× | 6.64× | 8.22× | IVV 5.62×, Oct 30 proxy only |

## Internet and Digital Platforms

- Industry total: **MISSING**. The internet proxy covers 29 NYU firms. Explain what its scope misses before using it.
- Test these three channels: online ad monetization, marketplace bookings and take rates, and subscription or cloud demand. Find a time series and cite it before calling any a durable driver.
- Investigate two risks: dependence on distribution or traffic acquisition, and competition or regulation that could limit monetization. For AI, distinguish capital spent, customer use, and cash earned.
- Technical evidence: FDN as a narrow ETF proxy. Record the 200-day average and 52-week high on the same date. The evidence sheet has the dated one-year return comparison.
- Your three drivers, two threats, two positives, two negatives, verdict and three selections: ___

## Pharma and Biotech

- Industry total: **MISSING**. Use the pharmaceutical column for the diversified cash-generating candidates and biotech as a separate sensitivity; the two are not interchangeable.
- Test these three channels: launches and uptake, geographic or payer mix, and pipeline milestones replacing lost exclusivity. Use dated company filings, trial registries and regulatory decisions.
- Investigate two risks: loss of exclusivity and clinical or reimbursement setbacks. For AI, separate an announced initiative from verified reductions in cost or time.
- Technical evidence: IHE for US pharma and IBB as a biotech comparison. Record both 200-day averages and 52-week highs if using both. The evidence sheet has dated return comparisons.
- Your three drivers, two threats, two positives, two negatives, verdict and three selections: ___
