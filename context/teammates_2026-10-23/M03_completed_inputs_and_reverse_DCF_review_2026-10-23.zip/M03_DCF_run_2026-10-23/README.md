# Completed M03 input/run package

Executed October 23, 2026. Start with REVERSE_DCF_REVIEW.md.

All eleven companies ran after factual input corrections. Method issues remain; these are conditional illustrations, not accepted investment valuations.

Open a terminal in this folder:
    python -X utf8 -m m03.run PYPL
    python -X utf8 -m unittest -v tests.test_m03

Python 3.9+ needs no external dependencies. UTF-8 mode avoids Windows encoding errors. This session used bundled Python with PYTHONUTF8=1.

inputs/m03 contains completed company inputs plus the blank template. reports contains completed session reports; reruns write into outputs. original_inputs preserves the supplied inputs. audit contains source checks, execution records, changed inputs, diagnostics and model review. The old supplied summary/rejection decisions are not presented as updated results. A generator that would reset corrected inputs is not included.

RESEARCH means a dated reported fact. ASSUMPTION means a forecast/proxy. Required numeric cash fields no longer substitute missing data with a researched zero. Omitted investments and unresolved senior claims remain explicitly described limitations.

Human source checks and rewriting remain pending.
