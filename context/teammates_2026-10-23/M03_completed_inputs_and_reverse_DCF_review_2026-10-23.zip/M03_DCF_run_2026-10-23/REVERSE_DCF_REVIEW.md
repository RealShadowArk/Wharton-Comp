# M03 execution and reverse DCF review

Prepared October 23, 2026. Source reads and execution times are in the audits. The supplied ZIP is named October 24; that date has not been used as the research cutoff.

**All 11 company runs completed successfully. Their numerical reverse roots reproduce the comparison prices within one cent. These are conditional reproductions of the supplied method with researched factual input corrections. They are not decision-ready valuations.**

Judgment: PYPL has the lowest growth hurdle under the kit assumptions; ZTS and BSX are closest to the supplied base cases. JKHY and HUBB require stronger growth than their base paths. LLY, ISRG and MPWR require particularly strong compounding. The model issues below prevent treating these differences as established mispricing.

## Conditional price-matching paths

All prices are the October 22 regular-session Close, freshly read from StockAnalysis on October 23 at 12:54:54 EDT. They are not live prices, Adjusted Close or WInS execution evidence. First-five-year figures are compound annual revenue growth, not arithmetic averages, earnings growth or expected returns. JKHY covers FY2027-31; the others cover FY2026-30.

The reverse solver shifts all ten annual growth rates by the same number of percentage points while holding other inputs fixed. It changes the nearly completed first fiscal year too, then returns to 3% growth after year ten. This is one price-matching path, not a unique market forecast.

| Company | Close used, USD | Conditional value / price | Base 5-year revenue CAGR | Price-matching 5-year revenue CAGR | Judgment |
|---|---:|---:|---:|---:|---|
| PYPL | 57.54 | 1.72x | 3.8% | -3.4% | Low conditional revenue hurdle; validate margins and cash conversion. |
| ZTS | 82.00 | 1.09x | 3.0% | 2.1% | Close to base; modest cushion depends on rates and proxy EBIT. |
| BSX | 46.01 | 1.00x | 7.4% | 7.4% | Near base-case pricing; cyber recovery and conversion dominate. |
| HUBB | 445.80 | 0.68x | 6.0% | 11.0% | Stronger sustained growth required; acquisition perimeter unresolved. |
| JKHY | 161.80 | 0.64x | 5.5% | 11.7% | Growth well above supplied path required; normalize cash taxes. |
| AME | 238.82 | 0.48x | 4.8% | 14.6% | Stronger growth required; reconcile acquisition cash economics. |
| ETN | 368.99 | 0.45x | 7.8% | 17.8% | Stronger sustained growth required; repair pretax-EBIT proxy. |
| ADI | 385.76 | 0.49x | 10.6% | 20.2% | Demanding beyond initial rebound; persistent cash plug matters. |
| ISRG | 443.85 | 0.44x | 13.5% | 26.4% | Strong sustained growth required; legal/tariff normalization matters. |
| LLY | 1,306.69 | 0.36x | 13.8% | 27.2% | High growth hurdle; pretax EBIT and synthetic cash limit inference. |
| MPWR | 1,167.93 | 0.30x | 15.3% | 33.1% | Highest growth hurdle; SBC, reinvestment and discount risk matter. |

Full growth paths, implied revenue levels, WACC, terminal scenarios and price residuals are in audit/numeric_results.json. Individual reports contain annual forecasts and the supplied sensitivity tables.

## Interpretation

- **PYPL:** About 3.4% annual revenue contraction matches price under fixed margins and conversion. That is a low revenue hurdle, but declining demand may also reduce margins. Validate SBC/dilution and BNPL cash timing. Corporate customer funds are excluded and other investments remain unvalued. The result does not establish a margin of safety.
- **ZTS and BSX:** Price-matching growth is near the base paths. ZTS has little modeled cushion against rate changes and still uses pretax income as EBIT. BSX guidance was superseded by its cyber warning; a mechanically near-one value/price ratio does not establish fair value while recovery remains unquantified.
- **JKHY and HUBB:** Required five-year revenue compounding is about 11-12%, versus roughly 5.5-6% in the base paths. JKHY needs cash-tax normalization. HUBB needs a single acquisition, financing and legacy-business perimeter.
- **AME, ETN and ADI:** Required sustained growth is materially above the supplied fades. Backlog or one rebound quarter does not establish that compounding. Reconcile acquisition investment for AME/ETN. ADI is especially sensitive to the perpetual cash-conversion residual.
- **LLY, ISRG and MPWR:** Matching prices requires about 27%, 26% and 33% first-five-year revenue CAGR, respectively. Compare those paths with capacity, demand, pricing and reinvestment. LLY needs IPR&D/manufacturing cash treatment, ISRG legal/tariff normalization and MPWR SBC/tax-control analysis.

## Input work completed

Filled the six asset entries marked MISSING: ZTS, LLY, BSX, AME, ETN and ADI. Amounts have dated original filing references; the bridge generally retains FY0 cash and debt rather than silently combining current cash with old debt. PYPL now uses verified corporate cash-only. ISRG uses matching FY2025 cash/investments instead of a mixed-date September figure. Cash-only cases exclude unvalued investments; exclusion is not a claim their value is zero. Treating all reported corporate cash as nonoperating remains an assumption because no operating-cash reserve was estimated.

Standardized prices to October 22. Replaced basic cover counts and rounded EPS-derived denominators with dated reported diluted weighted-average proxies where verified. They are not current fully diluted counts. WACC equity weights are explicitly approximate. FRED was reopened: 5.13% observation October 21, released October 22 at 16:16 EDT. Beta 1.0, 5% equity premium and forecast choices remain supplied assumptions.

No numeric growth, operating-margin, D&A or capex forecast paths were changed to improve the valuations. Future ratios are labeled assumptions and preserve their original research anchors. Engine code is byte-for-byte unchanged. Every input edit appears in audit/input_changes.csv; original files are retained.

## Material model limitations

1. **Timing and bridge:** Full first-year cash flow is discounted over a short remaining stub, usually 0.19 years and 0.02 for ADI. Old-date cash/debt can support an implicit roll-forward only if realized cash, distributions, buybacks, acquisitions and financing are reconciled. They are not. A simple one-year timing sensitivity is also not a corrected current-date valuation.
2. **Pretax is not EBIT:** ETN, LLY and ZTS retain the kit fallback. Financing costs remain in purported firm cash flow discounted at WACC, followed by debt subtraction. Reconstruct unlevered cash flow before accepting those enterprise results.
3. **Synthetic cash conversion:** Ten companies have a D&A plug containing SBC, working-capital and tax effects. LLY even has a negative synthetic first-year D&A value. Positive residuals persist while shares are fixed. The terminal formula combines a 20% NOPAT reinvestment deduction with that residual; economic consistency is unproven.
4. **Claims and scope:** Historical borrowing debt, omitted minority/senior claims, unquantified leases and acquisition-at-cost exclusions leave incomplete equity bridges. HUBB retains June acquisition financing in WACC while the legacy bridge excludes the acquisition.
5. **Terminal sensitivity:** About 47-54% of enterprise value is terminal value. The supplied growth sensitivity holds reinvestment at 20%, so changing growth changes implied return on new capital. The numeric audit includes a constant-15%-return-on-new-capital diagnostic using the same otherwise-provisional engine.

Removing only the terminal cash-conversion residual, with everything else fixed, changes ADI from about USD190 to USD139 per share and BSX from about USD46 to USD39. These are model diagnostics, not corrected valuations or price targets.

## Validation and next research action

All 11 supplied unit tests pass and all 11 final CLI calls returned zero. Independent arithmetic reconciles discounted cash flows, the enterprise/equity bridge and the price-matching roots. Higher WACC lowers value in every current case. Current curves increase across sampled solver brackets. Code audit found missing input/domain checks and reverse-solver failures for decreasing curves/NaN targets; these edge cases did not affect the finite current paths. Tests confirm implementation, not model economics.

Judgment: use the results to prioritize assumption challenges. Rebuild current-date FCFF and the equity bridge for one low-hurdle candidate and one high-growth candidate; separate D&A, SBC and working capital, correct pretax EBIT and reconcile reinvestment before relying on a valuation advantage. Human source checks and rewriting remain pending. No trades, calls, position sizes, Trading Notes or reflections are included.

Source URLs and actual read times appear in the input source columns and source audits. Individual quote links are in audit/price_sources.json. [FRED DGS10](https://fred.stlouisfed.org/series/DGS10) supports the risk-free observation.
