# M03 model audit

Read-only review of the original kit at `work/dcf/kit_original/Wharton_M03_DCF_kit`. No original code or inputs changed. Tests ran in the disposable copy `work/dcf/code_audit/m03_audit_0amydd3c/kit`. Line references below refer to original kit files.

The WACC equation and enterprise-to-equity bridge are arithmetically correct **when their inputs represent unlevered FCFF and the same business perimeter and valuation date**. The unchanged kit can produce conditional illustrations with explicit warnings. Correcting factual inputs alone does not validate the modelling choices below or make the reverse DCF an approved valuation.

## Material current-model issues

1. **Full-year cash flow versus remaining-period stub — critical date alignment.** `m03/dcf.py:58–66,96–100` discounts the entire first forecast fiscal year's FCFF at the supplied short first period; `m03/run.py:46` starts at base year plus one. Several inputs use 0.19 years and ADI uses 0.02. HUBB's `inputs/m03/HUBB_dcf_inputs.csv:24` explicitly justifies full FY2026 FCFF using December 2025 net debt, so this is an implicit cash roll-forward, not automatically double counting. But there is no reconciliation of realised cash generation, distributions, buybacks, acquisition cash or financing. Updating cash/debt to current balances while retaining the whole first year's FCFF risks counting already-realised cash twice. A current-date bridge needs a remaining-period stub, or the old-date bridge needs a complete capital roll-forward.

2. **Pretax income is not operating EBIT.** `tools/make_m03_inputs.py:49–56` substitutes pretax income for missing EBIT and sets net interest to zero. ETN, LLY and ZTS inputs explicitly use this fallback (`*_dcf_inputs.csv:8`). Their calibrated CFO-minus-capex remains after financing costs, yet is discounted at WACC and has debt subtracted (`m03/dcf.py:102`). Obtain operating EBIT and reconcile interest and other nonoperating items before treating these as enterprise FCFF results.

3. **Terminal cash plug needs economic reconciliation.** `m03/dcf.py:34–36,89–92` describes reinvestment as g/RONIC but calculates terminal FCFF as NOPAT × (1−reinvestment) **plus** D&A-minus-capex. If g/RONIC represents total net reinvestment/NOPAT, that growth funding is already deducted. A separate nonreplacement-amortisation add-back requires a consistent economic profit and capital definition; the supplied cash-conversion residual does not establish one. Removing only this terminal residual changes the model by approximately $51.29/share for ADI, $14.63 MPWR, $7.81 AME and $6.69 BSX, holding everything else fixed. These are isolated term contributions, not corrected valuations.

4. **D&A is a synthetic cash-conversion residual, including SBC and working capital.** `tools/make_m03_inputs.py:54–61,72–77` holds positive residuals forever, fades negative ones to zero, and sets separate NWC investment to zero. With fixed shares (`m03/dcf.py:106`), SBC add-backs receive no future dilution or cash-cost offset. Actual D&A/SBC/NWC and dilution treatment, or explicit adverse cash-conversion scenarios, are needed. The generator discloses this limitation; disclosure does not remove its valuation effect.

5. **Missing cash is an incomplete scenario, not a researched zero.** `m03/run.py:20–33` ignores labels when computing. ADI, BSX, AME, ETN, LLY and ZTS have zero nonoperating assets labelled MISSING; MPWR has missing investments. The appended input table preserves labels, but precise headline/reverse outputs still run. Omitted positive excess assets increase equity value dollar-for-dollar under otherwise identical assumptions and tend to lower required reverse growth on an increasing curve.

6. **Sensitivity and acquisition scope require labels.** Terminal-growth grid (`m03/run.py:59–61`) holds reinvestment at 20%; varying g from 2% to 4% therefore changes implied RONIC from 10% to 20%, rather than holding the stated 15% RONIC constant. HUBB weights include June 2026 NSI financing, while its bridge uses December 2025 debt/cash (`HUBB_dcf_inputs.csv:18,21–25`). Its acquisition-at-cost exclusion is explicit, but the WACC and forecast/bridge scopes are not fully aligned.

## Tests and reverse-solver limits

**All 11 supplied tests passed** using `python -m unittest -v tests.test_m03`. The terminal test (`tests/test_m03.py:53–57`) repeats the implemented formula; it does not independently validate its economics.

All 11 supplied growth/value curves were increasing when sampled at 1,001 points across the default ±50 percentage-point bracket. No current-path monotonicity failure was observed. Holding WACC and margins fixed is explicitly conditional, not itself a bug.

Adversarial probes nevertheless show robustness defects in `m03/dcf.py:132–148`:

- From the provided test fixture, set NWC investment/change-in-revenue to 5 and debt/assets to zero. Base price is 2.204545454545438, so shift zero is a valid root. The endpoint values are 21.863636363636353 and −17.45454545454539, but the solver returns None because it assumes an increasing curve.
- A NaN target price returns 0.4999995231628418, an apparent +50-point shift, rather than an error.
- Empty forecast tuples pass construction then raise IndexError; negative revenue and negative reinvestment are accepted. Validation checks only tuple lengths (`m03/dcf.py:38–42`). Duplicate CSV fields silently overwrite earlier values (`m03/run.py:23`).

These edge cases do **not** show that current supplied roots failed. They do show why every new input set needs finite/domain checks, bracket verification and a final price-residual check. A returned parallel growth shift is one price-matching scenario under fixed assumptions, not a unique statement of market expectations. All amounts here are calculations from kit inputs; financial facts and quotes were not independently reverified in this code audit.
