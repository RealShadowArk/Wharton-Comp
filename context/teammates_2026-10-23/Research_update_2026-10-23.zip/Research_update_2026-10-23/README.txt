Research update - 23 October 2026

Scope
This supplement covers all 33 active companies in the prior peer research. GPN, GEV and KMB remain outside this collection. Cash was requested for ZTS, BSX, AME, ETN, ADI and LLY only. The earlier v0.3 package and its pending scoring proposals are preserved.

The workbook is the main review file. Its Inputs sheet brings together the new inputs; Guidance preserves dated issuer forecasts and qualifications; Calendar returns and Beta history show the observations and calculations; International links the annual filings and records earnings currencies. The CSV is the 33-company input supplement and can be joined to the earlier peer table by ticker. It is not a replacement for the earlier financial statements or scores.

In the CSV, return and growth-rate columns are decimal fractions: -0.20 means -20%. Raw source records retain their declared units. Monetary cash and revenue columns use USD millions; EPS is USD per diluted share. Betas are unitless. The workbook applies percentage and currency display formats without rounding the stored inputs.

Cash
Both original annual and latest located interim cash are shown in USD millions. The latest verified interim dates are 30 June 2026 for five companies and 1 August 2026 for ADI. These are reported accounting balances, not daily cash on 23 October. Investments are excluded. Where the reported caption includes restricted cash, the separately quantified restriction is deducted and the reported amount is retained alongside it. ZTS's later annual comparative is recast; that supplemental amount does not silently replace the original audited observation. Cash fields for other companies are blank with NOT_REQUESTED status.

Beta
The primary beta uses exactly the same method for all 33 companies: an ordinary least-squares slope with an intercept against S&P 500 price-index returns. There are 60 completed monthly price returns, October 2021 through September 2026, from 61 month-end Close observations. October 2026 is excluded. The Yahoo Finance Beta (5Y Monthly) field is a separate provider comparison, available for 31 companies; it is not mixed into the common calculation. The source snapshot is 23 October, not the earlier 9 October valuation cutoff.

Worst calendar year
Each company's minimum is taken over its maximum available downloaded vendor history, through the last complete calendar year, 2025. The first incomplete quoted year and partial 2026 are excluded. Source boundaries, numbers of full years and history limitations are retained. This does not certify the minimum since the company's original exchange listing when earlier history is unavailable.

Two conventions remain separate: split-adjusted price return, and the provider's split/dividend-adjusted Close ratio, a total-return proxy. The latter was not independently rebuilt as a dividend-reinvestment portfolio. Corporate distributions can make the minima differ substantially. FIS and ROK have different worst years under the two measures; HUBB's historical class mapping and VRT's predecessor SPAC history are flagged. Some third-party adjusted-return tables disagree with the provider series. No maximum drawdown, partial-year decline or fabricated earlier return is substituted for a calendar year. No position sizing or application of the 2% rule is calculated.

Guidance
Guidance is the latest accessible primary issuer outlook located by 23 October, not analyst consensus. The publication date, fiscal target period, revenue basis and GAAP/non-GAAP distinctions control its use. Point estimates, ranges and qualitative phrases remain separate; a qualitative band is not assigned invented numeric endpoints.

BSX stated on 8 September that its July Q3/full-year ranges were unlikely to be met. Those ranges are historical only; no replacement is used before its scheduled 28 October update. PYPL's July outlook is verified, but the body of a later September newsletter could not be inspected, so later confirmation remains unresolved. MRK's September transaction charge, BMY's preliminary Q3 acquired-IPRD schedule and EMR's October accounting change are preserved as later component disclosures. They are not mechanically turned into new annual EPS ranges. Some companies' latest forecasts concern a fiscal year already ended by the cutoff; the period and availability notes make this visible.

International companies
ETN, MDT and NXPI currently file Form 10-K annual reports and present earnings in USD. Their foreign domicile does not establish Form 20-F status or euro-denominated earnings. NXP's FY2018 Form 20-F is included as an explicitly historical link; it is not used as the current annual report. The official MDT FY2026 PDF is included. Current ETN/NXPI reports and NXP's historical 20-F were opened online and are linked in the registry, but local downloads timed out or returned HTTP 403. Their download status is not represented as successful.

Evidence and verification
Research_evidence_2026-10-23.json preserves native cash amounts, conversions, source captions, guidance qualifications, market boundaries and source URLs. The market-history series and source snapshots are also retained in the task workspace. The two-page AI-use log accompanies this update. The manifest hashes each delivered file. Formula checks, membership, units, dates, explicit missing values and selected primary sources were reviewed. No TFS recalculation or approval of R1-R8 is implied.
