# Wharton Comp: Part A: Technology and financials (winner's-rule names) (follow-up, 19 Nov 2026)

**Context:** Laura Gao case. Our WInS portfolio is frozen, and the Final Report is due 4 Dec. Pat's universe screen has two rules:
- **our refined rule:** beta below the industry average;
- **the 2023 winner's rule:** alpha above the industry average **and** beta below it.

The companies below pass the **winner's rule** but were optional in the first packages, so nobody has collected their data yet. With the same Round 2 evidence for them, the team can compare the two strategies on one set of companies for **Laura's 2028 contribution** (Final Report, Section 3).

**Due: Pat sets the date (suggested: Mon 23 Nov, 9 pm ET).**
- Fill one tab per company in the attached `Team_Round2_data_template.xlsx`. Use the same format as your package.
- Send the workbook back to Pat with:
  - a Yahoo Finance **Max monthly** CSV for every company and for SPY;
  - a short AI-use log.

## Team rules (all packages)

- **Approved universe:** stocks, ETFs and Treasuries available on WInS, priced at $5 or more. Nothing else.
- **Labels:** label every figure **CASE / RESEARCH / ASSUMPTION** and give its source (filing, page, date). Write **MISSING** rather than guessing. Never fill a gap with a zero or an average.
- **AI use:** AI may find data and explain ideas, but **every figure must be checked against the filing**, and the notes must be in your own words. Keep a short log of which AI tool you used and for what: the Final Report must cite AI use in APA.
- **Do not decide buy or sell.** You collect evidence; Pat runs the models and decides.


## What to collect for each company

1. **Valuation inputs (Round 2 template):**
   - latest fiscal-year revenue, EBIT, D&A, capex, change in working capital and tax rate;
   - analyst consensus revenue growth for the next 3 years (source and date);
   - cash, debt (including finance leases), diluted shares;
   - the price on the date you collect.
2. **Bank-like companies (banks, insurers) instead need:**
   - book value per share;
   - net income and average equity for the last 3 years (for ROE);
   - dividends per share.
   - Mark them **RI method**.
3. **REITs instead need:**
   - FFO and AFFO for the last 3 years (company supplement);
   - dividends per share, net debt, diluted shares.
   - Mark them **FFO method**.
4. **Red-flag lines:** the inputs for the Piotroski and Beneish checks (template "Red flags" tab), for the last 2 years.
5. **Risk:** the worst calendar-year total return in USD since listing, with the year (for the 2% position cap).
6. **Management evidence:** one line of evidence for each of four items, **without scoring them** (Pat grades):
   - capital allocation;
   - guidance record (beats and misses over the last 8 quarters);
   - governance (board, share classes, related parties);
   - controversies and legal.
7. **AI exposure:** is this company an AI beneficiary, an AI adopter, or non-AI? Name one way AI could replace its products. One line each.

## Lessons from the first packages (please follow)

- **Two prices:**
  - the **30 Oct 2026 close** (our valuation date);
  - the price on the day you collect, with date and time.
- **Yahoo CSVs:** one Max monthly CSV for **every** company, plus SPY, downloaded unchanged.
- **Capex:** include capitalized software and "cash paid for intangible assets" as separate lines. Write MISSING if the company reports none.
- **Interest expense and interest income:** fill both lines. They feed the cash check.
- **One-off items:**
  - Flag any one-off tax item, such as a valuation-allowance release or charge, with its amount and page.
  - Do the same for any one-off gain or charge inside operating income.
- **Pending acquisitions or spin-offs:** give the deal price, how it is paid (cash, new debt, new shares), the expected close and the target's latest annual revenue. Consensus often already includes the target.
- **Fiscal year-end:** give the exact date (for example 27 Sep 2026).
- **WInS:** check each company in WInS (equity research or a trade ticket) and record the exchange and the price shown. Write MISSING if you cannot check.

## Part A companies (standard method)

| Company | Ticker | Group | Notes |
|---|---|---|---|
| Fortinet | FTNT | Information technology | Calendar year |
| PTC | PTC | Information technology | Fiscal year ends 30 Sep |
| Cadence Design Systems | CDNS | Information technology | Fiscal year ends around the start of January: give the exact date |
| Mastercard | MA | Financials: other | Standard method, like Fiserv and Cboe |

**Watch for:**
- **AI-replacement risk for software:** how AI could replace security, design or engineering software. One line each.
- **Fortinet:** product (hardware) revenue against service revenue, and whether guidance is billings or revenue.
- **Mastercard:**
  - corporate cash **excludes** restricted cash, litigation escrow and settlement or customer funds (the team convention for Intuit and Cboe);
  - give the amounts excluded;
  - debt includes finance leases.

## Top-ups for Package 1 names (only if you did Package 1)

- **T-Mobile (TMUS):** FY2025 interest expense and interest income.
- **Comcast (CMCSA):** FY2025 and FY2024 "cash paid for intangible assets" (capitalized software).
- **Fox (FOXA): Roku closed on 6 Nov.** For a combined valuation, give:
  - Roku shares acquired, new FOX Class A shares issued and total cash paid;
  - the new notes that replaced the $8.4bn bridge (amounts and coupons);
  - Fox's debt, cash and diluted shares after the close (latest filing);
  - Roku's latest annual revenue, operating income, D&A, capex, and cash and debt at the close.
- **Qualcomm (QCOM):** what lowered the FY2026 GAAP operating margin (20.1%, against 27.9% in FY2025). Give each one-off charge with its amount and 10-K page.
- **All six Package 1 names:** the WInS check.

## Top-ups for Package 3 names (only if you did Package 3)

- **Kimco (KIM):** AFFO per diluted share for FY2023-FY2025, from the company supplement. Write MISSING if Kimco doesn't publish it.
- **Realty Income (O):** the FY2026 consensus revenue growth (year 1 was MISSING).

## Return checklist

- [ ] One tab per company.
- [ ] Both prices (30 Oct close and collection date), the fiscal year-end date and the WInS check.
- [ ] Every figure has a label, a source and a date. Write MISSING where it's unavailable.
- [ ] Management evidence lines, AI-group lines and the worst year are filled in.
- [ ] Yahoo Max monthly CSVs for every company and SPY.
- [ ] A short AI-use log: the tool, what it was used for, and what you checked by hand.
